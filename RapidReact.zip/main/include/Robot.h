// 6055 2022 Rapid React

#pragma once

#include "frc/TimedRobot.h"
#include "frc/Joystick.h"
#include "frc/RobotController.h"
#include "frc/DriverStation.h"
#include "cameraserver/CameraServer.h"

#include "Constants.h"
#include "Drive.h"
#include "Intake.h"
#include "Climber.h"
#include "Shooter.h"
#include "Utility.h"
#include "networktables/NetworkTableInstance.h"

class Robot : public frc::TimedRobot 
{
 public:
  void RobotInit() override;
  void RobotPeriodic() override;
  void AutonomousInit() override;
  void AutonomousPeriodic() override;
  void TeleopInit() override;
  void TeleopPeriodic() override;
  void TestInit() override;
  void TestPeriodic() override;
  void DisabledInit() override;
  void DisabledPeriodic() override;
  void RunAuto_1();
  void RunAuto_2();
  void Climb_High();
  void Climb_High2();
  void LimeLight_TargetMode();
  void LimeLight_CameraMode();
  double LimeLight_GetDistance();
    
  int AutoState = 0;
  int ClimbState = 0;
  int ClimbMode = 0;  //manual teleop=0, climb high bar=1, climb traverse bar=2
  int CurMode = 0;  //auto=1, teleop=2, test=3
  units::time::second_t ClockStart;
  units::time::second_t ClockNow;
  double VisionTargetY = 0.0;
  double lpfVTY = 0.1;
  double VisionTargetV = 0.0;
  double lpfVTV = 0.3;
  
  
  //limelight networktable
  std::shared_ptr<nt::NetworkTable> ntCameraData;

  //dashboard variables
  bool FMSMatch = false;  //true if attached to FMS
  bool MatchStart = false;
  int dAutoSelect = 0;
  int dTestSelect = 0;

 private:
  
  frc::Joystick *Joystick0;
  frc::Joystick *Joystick1;
  frc::Joystick *Joystick2;

  frc::Timer *AutoTimer;
  frc::Timer *ModeTimer;

  DriveClass *Drive;
  IntakeClass *Intake;
  ClimberClass *Climber;
  ShooterClass *Shooter;
  //usbcamera - only used when constants::kUSBCameraEnabled = true
  //cs::UsbCamera camera;
  
  //BOSS dashboard networktable 
  std::shared_ptr<nt::NetworkTable> ntBOSS;
};

