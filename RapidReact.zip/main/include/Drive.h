#pragma once

#include "Constants.h"
#include "Utility.h"
#include "Auto_5.h"
#include "Auto_CurlLeft.h"
#include "Auto_CurlRight.h"
#include "ctre/Phoenix.h"

#include <iostream>
#include "networktables/NetworkTableInstance.h"
#include "frc/Errors.h"

class DriveClass 
{
 public:
  
  int AutoSelection = 0;
  short DriveFault = 0;
  double MotorLFMaxAmps;
  double MotorLRMaxAmps;
  double MotorRFMaxAmps;
  double MotorRRMaxAmps;

  struct OutputToDrive
  {
      double Left;
      double Right;
  };
  
  
  void Init();
  void DriveTank(double leftSpeed, double rightSpeed, double deadband, bool squareInputs, bool reversed);
  void DriveArcade(double xSpeed, double zRotation, double deadband, bool squareInputs, bool reversed); 
  void DriveArcade2(double xSpeed, double zRotation, double deadband, bool squareInputs, bool reversed); 
  void TestDrive(double left, double right);
  double GetLFDistance(); //returns Feet travelled
  double GetRFDistance(); //returns Feet travelled
  double GetLFSpeed(); //returns Feet/sec
  double GetRFSpeed(); //returns Feet/sec
  void ZeroDistance();
  void AutoSelect(int autoSelection);
  void AutoPeriodic();
  void AutoStart_Rev5();
  void AutoStart_Fwd5();
  void AutoStart_CurveLeft();
  void AutoStart_CurveRight();
  bool AutoIsRunning();
  void AutoReset();
  void Disable();
  void CheckFaults();
  void ClearStickyFaults();
  void InitBuffer(BufferedTrajectoryPointStream *bufstrm, const double profile[][2], int totalCnt, bool reverse); 
  void FX_CheckFaults(WPI_TalonFX *Motor,std::string name,short bit);
  void SRX_CheckFaults(WPI_TalonSRX *Motor,std::string name,short bit);
  void GetMaxAmps(bool SendToDash);
  void ResetMaxAmps();
  
 private:
  
  WPI_TalonFX *MotorLF;
  WPI_TalonFX *MotorRF;
  WPI_TalonFX *MotorLR; //slaved to MotorLF
  WPI_TalonFX *MotorRR; //slaved to MotorRF

  BufferedTrajectoryPointStream *AutoRev5_LeftBufStrm;
  BufferedTrajectoryPointStream *AutoRev5_RightBufStrm;
  BufferedTrajectoryPointStream *AutoFwd5_LeftBufStrm;
  BufferedTrajectoryPointStream *AutoFwd5_RightBufStrm;
  BufferedTrajectoryPointStream *AutoFwdCL_LeftBufStrm;
  BufferedTrajectoryPointStream *AutoFwdCL_RightBufStrm;
  BufferedTrajectoryPointStream *AutoFwdCR_LeftBufStrm;
  BufferedTrajectoryPointStream *AutoFwdCR_RightBufStrm;

  std::shared_ptr<nt::NetworkTable> ntBOSS;
  
};

