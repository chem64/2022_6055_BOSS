//constants.h    keeper of the magic numbers
#pragma once

#include <wpi/numbers>

namespace constants
{
    constexpr double kPI = wpi::numbers::pi;
    constexpr bool kAutoLoggingEnabled = false;
    constexpr bool kDriveLoggingEnabled = false;
    constexpr bool kIntakeLoggingEnabled = false;
    constexpr bool kShooterLoggingEnabled = false;
    constexpr bool kClimberLoggingEnabled = false;
    constexpr bool kUSBCameraEnabled = false;
    constexpr bool kLimeLightEnabled = true;

    namespace limelight
    {
        constexpr double MinDistance = 10; //set this to calibration data
        constexpr double MaxDistance = 25; //set this to calibration data
        constexpr double MinSpeed = -0.7; //set this to calibration data
        constexpr double MaxSpeed = -1.00; //set this to calibration data
        constexpr double TargetHeight = 8.0; //feet to center of target
        constexpr double CameraHeight = 2.0;  //feet to camera lens
        constexpr double CameraAngle = 0.0;  
    }

    namespace drive
    {
        //use only one of these three
        constexpr bool kDriveWithArcade = true;
        constexpr bool kDriveWithTank = false;
        constexpr bool kDriveWithXbox = false;

        constexpr double kJoystickSlewRate = 1.0;
        constexpr bool kSilenceJoystickWarnings = true;

        constexpr int kMotorLF_ID = 5;
        constexpr int kMotorLR_ID = 6;
        constexpr int kMotorRF_ID = 7;
        constexpr int kMotorRR_ID = 8;
        //for motion profile
        // kF -  measure velocity in u/100ms @ 100% throttle
        // kF = 1023 / (u/100ms @ 100% throttle)
        constexpr double kF = 0.015;     //FeedForward
        // kP = throttle per error unit.  ex: 102 is 9.97% (102/1023) throttle per 1 unit of Closed Loop Error
        constexpr double kP = 1.0;       //Proportional Gain
        // kI = throttle per integrated error.  ex: 10 = 0.97% for each accumulated error (Integral Accumulator)
        constexpr double kI = 0.001;     //Integral Gain
        // kD = throttle per derivative error.  ex: 102 equals 9.97% (102/1023) per change of Position/Velocity unit per 1ms
        constexpr double kD = 0.5;       //Derivative Gain
        constexpr double kOpenLoopRamp = 0.15;
        //Supply Limiting is to prevent breakers tripping or brownouts
        constexpr double kSupplyCurrentLimit = 35.0; //amps
        constexpr double kPeakCurrentLimit = 40.0; //amps
        constexpr double kPeakCurrentDuration = 25; //msecs
        //Stator limiting is to limit acceleration or heat
        constexpr double kStatorCurrentLimit = 30.0;
        constexpr double kStatorPeakCurrentLimit = 35.0; //amps
        constexpr double kStatorPeakCurrentDuration = 15; //msecs
        constexpr double kVoltageCompSaturation = 12.0;

        //auto profile - drive wheel position - convert Feet to position units (encoder count)
        constexpr double kCPR = 2048;
        constexpr double kGearRatio = 7.71;
        constexpr double kFeetPerRotation = 1.04719;
        constexpr double kFeetToUnits = (kCPR * kGearRatio) / kFeetPerRotation; 
        constexpr double kUnitsToFeet = 1 / kFeetToUnits;  
        //auto profile - drive wheel speed - convert from Feet/Sec to  units/100ms
        constexpr double kFPSToUnits = ((kFeetPerRotation * kGearRatio) / 10) * kCPR;  
        constexpr double kUnitsToFPS = 1 / kFPSToUnits;  
    }

    namespace shooter
    {
        constexpr int kMotorShooter1_ID =  9;
        constexpr int kMotorShooter2_ID =  10;
        constexpr int kMotorFeeder_ID = 11;
        //velocity - set closed loop ramp. set all gains to 0.
        //           run shooter at full speed and get velocity in units/100ms
        //           calculate kF as 1023/maxvelocity
        constexpr double kF = 0.065; //0.015;     //FeedForward  = 
        constexpr double kP = 0.0;     //0.4;    //Proportional Gain
        constexpr double kI = 0.0;     //Integral Gain
        constexpr double kD = 0.0;     //Derivative Gain 
        constexpr double kClosedLoopRamp = 0.25;
        
        //current limiting
        constexpr double kSupplyCurrentLimit = 30.0;
        constexpr double kPeakCurrentLimit = 35.0;
        constexpr double kPeakCurrentDuration = 25; //msecs
        constexpr double kContinuousCurrentLimit = 30.0;
        constexpr double kVoltageCompSaturation = 12.0;

        //feeder wheels
        constexpr double kFeederSpeed = -0.75;
        
        //shooter - convert from/to RPM
        constexpr double kCPR = 2048;
        constexpr double kRPMToUnits = kCPR / 600; // Units/100ms
        constexpr double kUnitsToRPM = 1 / kRPMToUnits; 
        constexpr double kFeederDelaySecs = 1.0;
        constexpr double kRPM_LowGoal = 1100;
        constexpr double kRPM_9ft = 1750;
        constexpr double kRPM_16ft = 2000;
        constexpr double kRPM_Auto1 = 1600;
        constexpr double kRPM_Auto2 = 1600;
    }

    namespace intake
    {
        constexpr int kMotorIntakeWheels_ID = 12;
        constexpr int kMotorIntakePosition_ID = 13;
        //motion magic - zero all gains, start with kP.  Add kD to smooth.  Add kI (very little) to reduce position error.
        constexpr double kF = 0.2;     //FeedForward  0.2
        constexpr double kP = 0.75;     //Proportional Gain  0.75
        constexpr double kI = 0.001;   //Integral Gain  0.001
        constexpr double kD = 0.5;     //Derivative Gain  0.5
        constexpr double kMotionCruiseVelocity = 4000;
        constexpr double kMotionAcceleration = 8000;
        constexpr double kMotionSCurveStrength = 5;
        constexpr double kOpenLoopRamp = 1.0;

        //current limiting
        constexpr double kContinuousCurrentLimit = 15.0;
        constexpr double kSupplyCurrentLimit = 20.0;
        constexpr double kPeakCurrentLimit = 20.0;
        constexpr double kPeakCurrentDuration = 25; //msecs
        constexpr double kVoltageCompSaturation = 12.0;

        //intake wheels
        constexpr double kIntakeSpeed = -1.0;
        
        //intake position - use static counts
        constexpr int kPos_Extend = 3460;  
        constexpr int kPos_Retract = 0;    
        constexpr double kPositionExtendLimit = 3460;
        constexpr double kPositionRetractLimit = 0;
    }

    namespace climber
    {
        constexpr int kMotorArmStat1_ID = 14;
        constexpr int kMotorArmStat2_ID = 15;
        constexpr int kMotorArmRot1_Extend_ID = 16;
        constexpr int kMotorArmRot2_Extend_ID = 17;
        constexpr int kMotorArmRot1_Rotate_ID = 18;
        constexpr int kMotorArmRot2_Rotate_ID = 19;
        //motion magic - zero all gains, start with kP.  Add kD to smooth.  Add kI (very little) to reduce position error.
        constexpr double kSpin_F = 0.2;     //FeedForward
        constexpr double kSpin_P = 0.5;     //Proportional Gain
        constexpr double kSpin_I = 0.0;   //Integral Gain
        constexpr double kSpin_D = 0.0;     //Derivative Gain 
        constexpr double kSpin_MotionCruiseVelocity = 5000;
        constexpr double kSpin_MotionAcceleration = 10000;
        constexpr double kSpin_MotionSCurveStrength = 5;
        //motion magic - zero all gains, start with kP.  Add kD to smooth.  Add kI (very little) to reduce position error.        
        constexpr double kArmExt_F = 0.9;     //FeedForward
        constexpr double kArmExt_P = 2.3;     //Proportional Gain
        constexpr double kArmExt_I = 0.005;   //Integral Gain
        constexpr double kArmExt_D = 0.0;     //Derivative Gain 
        constexpr double kArmExt_MotionCruiseVelocity = 60000;
        constexpr double kArmExt_MotionAcceleration = 120000;
        constexpr double kArmExt_MotionSCurveStrength = 5;

        //motion magic - zero all gains, start with kP.  Add kD to smooth.  Add kI (very little) to reduce position error.
        constexpr double kArmRot_F = 0.015;    //FeedForward
        constexpr double kArmRot_P = 0.05;     //Proportional Gain
        constexpr double kArmRot_I = 0.005;     //Integral Gain
        constexpr double kArmRot_D = 0.0;    //Derivative Gain 
        constexpr double kArmRot_AFF = 0.0;  //arbitrary FeedForward to account for gravity on the arm
        constexpr double kArmRot_MotionCruiseVelocity =50000;
        constexpr double kArmRot_MotionAcceleration = 100000;
        constexpr double kArmRot_MotionSCurveStrength = 5;
        
        //current limiting
        constexpr double kContinuousCurrentLimit = 20.0;
        constexpr double kSupplyCurrentLimit = 20.0;
        constexpr double kPeakCurrentLimit = 25.0;
        constexpr double kPeakCurrentDuration = 25; //msecs
        constexpr double kVoltageCompSaturation = 12.0;

        //extending arm - use static counts
        constexpr double kArmExt_ExtendLimit = 34500; //max possible move in any mode
        constexpr double kArmExt_ExtendCounts = 31150;//extended target in manual mode
        constexpr double kArmExt_RetractCounts = 10;  //retracted target in manual mode
        constexpr double kArmExt_RetractLimit = 0;    //min possible move in any mode
        constexpr double kArmExt_TeleopLimit = 30000;//extended limit in manual mode
        constexpr double kArmExt_AllowableError = 20;
        constexpr double kArmExt_PositionDB = 40;     //deadband around target for determining "at position"
        constexpr int    kArmExt_TargetDelay = 6;    //in 20ms counts, 50 = 1 sec
        constexpr double kArmExt_ExtendSpeed = 0.8;   //teleop extend speed
        constexpr double kArmExt_RetractSpeed = -0.7; //teleop retract speed

        //spinner hooks - convert to degrees
        constexpr double kSpinCPR = 4096;
        constexpr double kSpinGearRatio = 3.33;
        constexpr double kSpinCountsPerRevolution = kSpinCPR * kSpinGearRatio; 
        constexpr double kSpinDegreesToUnits = (kSpinCPR * kSpinGearRatio) / 360;
        constexpr double kSpinUnitsToDegrees = 1 / kSpinDegreesToUnits;
        constexpr double kArmStat_RotateCounts = kSpinCountsPerRevolution/2;
        constexpr int    kSpin_TargetDelay = 12;    //in 20ms counts, 50 = 1 sec
 
        //rotating arm 
        constexpr double kArmRot_ForwardLimit = 592;   //max forward movement - should be forward stop
        constexpr double kArmRot_ReverseLimit = 492;   //min reverse movement - should be reverse stop
        constexpr double kArmRot_Range = kArmRot_ForwardLimit - kArmRot_ReverseLimit;
        constexpr double kArmStartPosition = kArmRot_ForwardLimit * 0.99; //340   //set to starting arms position
        constexpr double kArmsAreClear = kArmRot_ReverseLimit * 1.194; //289 set to position where safe to move spinners
        constexpr double kArmRot_AllowableError = 0.03 * kArmRot_Range;   //deadband around target for position control
        constexpr double kArmRot_PositionDB = 0.05 * kArmRot_Range;       //deadband around target for determining "at position"
        constexpr int    kArmRot_TargetDelay = 6;        //in 20ms counts, 50 = 1 sec
        constexpr bool   kArmRot2_UpdateFollower = true; //turn this on if more problems with following
        constexpr bool   kArmRot_UsePlanetaryGearbox = false;  //turn on if we swap gearboxes - and change limit values

        //high bar climb
                                                       //Step 1 -hook spinners
        constexpr double kStep2ExtendPosition = 6500;  //Step 2 -up just a little to allow rotation
        constexpr double kStep3ExtendPosition = 34000; //Step 3 -full extend
        constexpr double kStep3RotatePosition = kArmRot_ForwardLimit * 0.99;   //341       -full rotate
        constexpr double kStep4RotatePosition = kArmRot_ForwardLimit * 0.90;  //300   Step 4 -rotate back to touch high bar
        constexpr double kStep5ExtendPosition = 29000; //Step 5 -retract extending hooks to latch high bar
                                                       //Step 6 - unhook spinners
        constexpr double kStep7RotatePosition = kArmRot_ReverseLimit * 1.004;   //Step 7 -rotate back to vertical
        constexpr double kStep7ExtendPosition = 10;   //       -pull up all the way on high bar

        //traverse bar climb
                                                        //Step 8 -hook spinners
        constexpr double kStep9ExtendPosition = 6500;   //Step 9 -up just a little to allow rotation
        constexpr double kStep10ExtendPosition = 34000; //Step 10 -full extend
        constexpr double kStep10RotatePosition = kArmRot_ForwardLimit * 0.99; //341      -full rotate
        constexpr double kStep11RotatePosition = kArmRot_ForwardLimit * 0.90; //300  Step 11 -rotate back to touch traverse bar
        constexpr double kStep12ExtendPosition = 29000; //Step 12 -retract extending hooks to latch traverse bar
                                                        //Step 13 - unhook spinners
        constexpr double kStep14RotatePosition = kArmRot_ReverseLimit * 1.004; //240  Step 14 -rotate back to vertical
        constexpr double kStep14ExtendPosition = 50;   //       -pull up all the way on traverse bar
    }
}