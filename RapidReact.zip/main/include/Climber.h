#pragma once

#include "Constants.h"
#include "Utility.h"
#include "ctre/Phoenix.h"
#include <iostream>
#include "networktables/NetworkTableInstance.h"

#include "utility.h"

class ClimberClass 
{
 public:
  
  
  
  int ArmRot_Setpoint = 0;
  double ArmExt_Setpoint = 0;
  double ArmSpin_Setpoint = 0;
  short ClimberFault = 0;
  double Spinner1MaxAmps;  
  double Spinner2MaxAmps;  
  double Extend1MaxAmps;  
  double Extend2MaxAmps;  
  double Rotate1MaxAmps;  
  double Rotate2MaxAmps;  
  
  
  void Init();
  void Periodic(double joyRotation, bool butExtend, bool butSpin);
  void AutoPeriodic();
  void Disable();
  void EnableSoftReverseLimits(bool enable);
  void ArmStat_RotateHook();
  void TestSpinners(double output);
  void TestSpinner1(double output);
  void TestSpinner2(double output);
  void MoveSpinnersIN();
  void MoveSpinnersOUT();
  void TestArmExtend(double output);
  void TestArmExtend1(double output);
  void TestArmExtend2(double output);
  void TestArmRotate(double output);
  void TestArmRotatePosition();
  void TestArmSpinPosition(bool butSpin);
  void TestArmExtendPosition();
  bool SpinnersAreFreeToMove();
  bool SpinnersAreIN();
  bool SpinnersAreHooked();
  bool SpinnersAreNotHooked();
  void SyncRotateSetpoint();
  void SyncExtendSetpoint();
  double GetPosArmStat1();
  double GetPosArmStat2();
  double GetPosArmRot1Extend();
  double GetPosArmRot2Extend();
  bool ExtendersAreAtPosition();
  double GetPosArmRotRotate();
  bool RotatingArmsAtPosition();
  void CheckFaults();
  void ClearStickyFaults();
  void FX_CheckFaults(WPI_TalonFX *Motor,std::string name,short bit);
  void SRX_CheckFaults(WPI_TalonSRX *Motor,std::string name,short bit);
  void GetMaxAmps(bool SendToDash);
  void ResetMaxAmps();
  void ZeroSpin();
  void ZeroExtend();
  void ZeroRotate();
  void ResetRotateFollow();
  
 private:
  
  WPI_TalonSRX *MotorArmStat1;
  WPI_TalonSRX *MotorArmStat2; //slaved to MotorArmStat1
  WPI_TalonSRX *MotorArmRot1_Extend;
  WPI_TalonSRX *MotorArmRot2_Extend; //slaved to MotorArmRot1_Extend
  WPI_TalonFX *MotorArmRot1_Rotate;
  WPI_TalonFX *MotorArmRot2_Rotate; //slaved to MotorArmRot1_Rotate

  std::shared_ptr<nt::NetworkTable> ntBOSS;
  
};

