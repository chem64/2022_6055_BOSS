#pragma once
#include "frc/Timer.h"
#include <units/time.h>
#include "frc/filter/SlewRateLimiter.h"

//returns value if outside given deadband - otherwise zero  (mainly for joysticks)
double Deadband(double value, double deadband);
//returns moving average filter for smoothing rapidly changing values
double GetMovingAverage(double rawValue, double filter);
//returns distance in feet from LimeLight camera
double GetVisionDistance(double VisionY, double TgtHeight, double CamHeight, double CamAngle);

//template <typename t>
double clamp2(double x, double min, double max);

short setBit(short n, short k);
short clearBit(short n, short k);

//class to debounce digital input signals
class Debounce
{
private:
	frc::Timer *mTimer;
	int mState;
public:
  Debounce();   //constructor   
  ~Debounce();  //destructor
  bool OnDelay(bool Enabled, bool InputOn, units::time::second_t DelayTime);
  bool OffDelay(bool Enabled, bool InputOn, units::time::second_t DelayTime);
};



