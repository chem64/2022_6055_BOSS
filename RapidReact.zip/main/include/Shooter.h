#pragma once

#include "Constants.h"
#include "Utility.h"
#include "ctre/Phoenix.h"
#include <iostream>
#include "networktables/NetworkTableInstance.h"

class ShooterClass 
{
 public:
  
  
  double Shooter_Speed = 0; 
  double Feeder_Speed = constants::shooter::kFeederSpeed;
  double buttonFlag = false;
  short ShooterFault = 0;
  double Shooter1MaxAmps;
  double Shooter2MaxAmps;
  double FeederMaxAmps;
  double Shooter1MaxUnits;
  double Shooter2MaxUnits;
  
  
  void Init();
  void Periodic(bool button, double rpm);
  void TestShooter(double speed);
  void TestFeeder(double speed);
  void Disable();
  double GetShooterRPM();
  void ClearShooterKF();
  void CalcShooterKF();
  void CheckFaults();  
  void ClearStickyFaults();
  void FX_CheckFaults(WPI_TalonFX *Motor,std::string name,short bit);
  void SRX_CheckFaults(WPI_TalonSRX *Motor,std::string name,short bit);
  void GetMaxAmps(bool SendToDash);
  void ResetMaxAmps();
  
 private:
  
  WPI_TalonFX *MotorShooter1;
  WPI_TalonFX *MotorShooter2; //slaved to MotorShooter
  WPI_TalonSRX *MotorFeeder;

  frc::Timer *FeedTimer;

  std::shared_ptr<nt::NetworkTable> ntBOSS;
  
};

