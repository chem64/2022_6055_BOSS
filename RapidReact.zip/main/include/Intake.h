#pragma once

#include "Constants.h"
#include "Utility.h"
#include "ctre/Phoenix.h"
#include <iostream>
#include "networktables/NetworkTableInstance.h"

class IntakeClass 
{
 public:
  
  double Whl_Speed = constants::intake::kIntakeSpeed;
  double Pos_Target = 0.0;
  short IntakeFault = 0;
  double IntakeWheelsMaxAmps;  
  double IntakePositionMaxAmps;
  
  void Init();
  void Periodic(bool butIntake, bool wheelsOnly);
  void Disable();
  void EnableSoftReverseLimits(bool enable);
  void TestIntakePosition(double output);
  void TestIntakeWheels(double output);
  void ZeroPosition();
  void CheckFaults();
  void ClearStickyFaults();
  void FX_CheckFaults(WPI_TalonFX *Motor,std::string name, short bit);
  void SRX_CheckFaults(WPI_TalonSRX *Motor,std::string name, short bit);
  void GetMaxAmps(bool SendToDash);
  void ResetMaxAmps();
  
 private:
  
  WPI_TalonSRX *MotorIntakeWheels;
  WPI_TalonSRX *MotorIntakePosition;

  std::shared_ptr<nt::NetworkTable> ntBOSS;
  
};

