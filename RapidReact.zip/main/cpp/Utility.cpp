#include "Utility.h"

//public function to return deadband value given deadband limit
double Deadband(double value, double deadband) 
{
  if (std::abs(value) > deadband) {
    if (value > 0.0) {
      return (value - deadband) / (1.0 - deadband);
    } else {
      return (value + deadband) / (1.0 - deadband);
    }
  } else {
    return 0.0;
  }
}

double GetMovingAverage(double rawValue, double filter)
{
  if(filter <= 0.0)  filter = 0.001; //max filter
  if(filter > 1.0) filter = 1.0; //no filter 
  return  filter * rawValue + ((1-filter)*rawValue);
}

double GetVisionDistance(double VisionY, double TgtHeight, double CamHeight, double CamAngle)
{
  double degTorad = 0.0174533;
  return (TgtHeight - CamHeight) /tan((VisionY+CamAngle)*degTorad);
}

//template <typename t>
double clamp2(double x, double min, double max)
{
  if (x < min) x = min;
  if (x > max) x = max;
  return x;
}

//class Debounce
Debounce::Debounce()
{
  mState = 0;
	mTimer = new frc::Timer();
  mTimer->Start();
}

Debounce::~Debounce()
{
  mState = 0;
  mTimer->Stop();
  delete mTimer;
	mTimer = nullptr;
}

bool Debounce::OnDelay(bool Enabled, bool InputOn, units::time::second_t DelayTime)
{
  bool ret = false;
  if(Enabled)
  {
    switch(mState)
    {
    case 0: //checking for input signal to be made
        ret = false;
        if(InputOn)
        {
            mTimer->Reset();
            mState = 10;
        }
        break;
    case 10: //wait for delay time
        ret = false;
        if(mTimer->AdvanceIfElapsed(DelayTime)) mState = 20;
        break;
    case 20: 
        ret = true;
        break;
    }
    if(!InputOn) //immediately return false if we lose input
    {
        mState = 0;
        ret = false;
    }
  }
  else //return false if not enabled
  {
    mState = 0;
    ret = false;
  }
  return ret;
}

bool Debounce::OffDelay(bool Enabled, bool InputOn, units::time::second_t DelayTime)
{
  bool ret = false;
  if(Enabled)
  {
    switch(mState)
    {
      case 0: //checking for input signal to be made
        ret = false;
        if(InputOn)
        {
          ret = true;
          mState = 10;
        }
        break;
      case 10: //checking for input signal to go off
        ret = true;
        if(!InputOn) 
        {
          mTimer->Reset();
          mState = 20;
        }
        break;
      case 20: //wait for delay time before returning off
        ret = true;
        if(mTimer->AdvanceIfElapsed(DelayTime)) mState = 0;
        break;
    }
    if(InputOn) //immediately return true if input is on
    {
      mState = 0;
      ret = true;
    }
  }
  else
  {
    mState = 0;
    ret = false;
  }
  return ret;
}

// Function to set the kth bit of n
short setBit(short n, short k)
{
  //short pt = n;
    return (n | (1 << k));
    //pt |= (n << ndx);
    //return pt;
}
  
// Function to clear the kth bit of n
short clearBit(short n, short k)
{
    return (n & (~(1 << k)));
}

