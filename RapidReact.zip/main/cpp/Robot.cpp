// 6055 2022  Rapid React

#include "Robot.h"
using namespace frc;

void Robot::RobotInit() 
{
  printf("%s\n","ROBOT INIT");
  //BOSS dashboard on Drive Station computer
  ntBOSS = nt::NetworkTableInstance::GetDefault().GetTable("dashBOSS");
  //notify dashboard we are outputting diagnostic data
  ntBOSS->PutNumber("AutoLoggingEnabled", constants::kAutoLoggingEnabled);
  ntBOSS->PutNumber("ClimberLoggingEnabled", constants::kClimberLoggingEnabled);
  ntBOSS->PutNumber("DriveLoggingEnabled", constants::kDriveLoggingEnabled);
  ntBOSS->PutNumber("IntakeLoggingEnabled", constants::kIntakeLoggingEnabled);
  ntBOSS->PutNumber("ShooterLoggingEnabled", constants::kShooterLoggingEnabled);

  //turn off warnings for joysticks not connected
  DriverStation::SilenceJoystickConnectionWarning(constants::drive::kSilenceJoystickWarnings);

  //instantiate three joysticks - only use 2 or 3 depending on configuration
  Joystick0 = new frc::Joystick(0); //usb 0 - drive for arcade/xbox, left drive for tank
  Joystick1 = new frc::Joystick(1); //usb 1 - player for arcade/xbox, right drive for tank
  Joystick2 = new frc::Joystick(2); //usb 2 - player for tank

  //instantiate system classes
  Drive = new DriveClass();
  Drive->Init();
  Intake = new IntakeClass();
  Intake->Init();
  Shooter = new ShooterClass();
  Shooter->Init();
  Climber = new ClimberClass();
  Climber->Init();

  ntCameraData = nt::NetworkTableInstance::GetDefault().GetTable("limelight");
  if(constants::kLimeLightEnabled) LimeLight_CameraMode();
  
  FMSMatch = frc::DriverStation::IsFMSAttached(); //is this a real match with FMS
  AutoTimer = new Timer();
  AutoTimer->Start();
  ModeTimer = new Timer();
  ModeTimer->Start();

  ClockStart = frc::Timer::GetFPGATimestamp();

  //if(constants::kUSBCameraEnabled) camera = CameraServer::GetInstance()->StartAutomaticCapture();
  if(constants::kUSBCameraEnabled) frc::CameraServer::StartAutomaticCapture();

  ntBOSS->PutString("AutoStatus", "");
}

void Robot::RobotPeriodic() //runs every 20ms
{
  //only update this until match starts
  if(!MatchStart)
  {
    static int tempCounter = 0;
    tempCounter++;
    if(tempCounter >= 50) //1 secs
    {
      //Read AutoSelect and write AutoSelected on BOSS dashboard
      dAutoSelect = (int) ntBOSS->GetNumber("AutoSelect", 0.0);
      ntBOSS->PutNumber("AutoSelected", dAutoSelect);
      //Read TestSelect and write TestSelected on BOSS dashboard
      dTestSelect = (int) ntBOSS->GetNumber("TestSelect", 0.0);
      ntBOSS->PutNumber("TestSelected", dTestSelect);
      //allow BOSS dashboard to reset sticky faults
      int ResetStickyFaults = (int) ntBOSS->GetNumber("ResetStickyFaults", 0);
      if(ResetStickyFaults == 1)
      {
        Drive->ClearStickyFaults();
        Intake->ClearStickyFaults();
        Shooter->ClearStickyFaults();
        Climber->ClearStickyFaults();
        ntBOSS->PutNumber("ResetStickyFaults", 0);
      }
      ntBOSS->PutNumber("ClockMode", 0);
    }
  }

  static int counter = 0;
  counter++;
  if(counter >= 13) //250 msecs
  {
      ClockNow = frc::Timer::GetFPGATimestamp();
      counter = 0;
      if(IsAutonomousEnabled())
      {
        ntBOSS->PutNumber("ClockMode", 1);
        ntBOSS->PutNumber("ClockElapsed", clamp2(15.0 - (double)(ClockNow - ClockStart),0.0,15.0));
      }
      if(IsTeleopEnabled())
      {
        ntBOSS->PutNumber("ClockMode", 2);
        ntBOSS->PutNumber("ClockElapsed", clamp2(75.0 - (double)(ClockNow - ClockStart),0.0,75.0));
      }
      ntBOSS->PutNumber("CurMode", CurMode);
  }
}

void Robot::AutonomousInit() 
{
  CurMode = 1;
  ClockStart = frc::Timer::GetFPGATimestamp();
  MatchStart = true;
  //last chance check for auto selection
  dAutoSelect = (int) ntBOSS->GetNumber("AutoSelect", dAutoSelect);
  //set the selected auto to be run
  Drive->AutoSelect(dAutoSelect);
  AutoState = 0;
  switch(dAutoSelect)
  {
    case 0: 
      printf("%s\n","NO AUTO SELECTED");
      break;
    case 1: 
      printf("%s\n","1 BALL AUTO SELECTED");
      break;
    case 2: 
      printf("%s\n","2 BALL STRAIGHT AUTO SELECTED");
      break;
    case 3: 
      printf("%s\n","2 BALL CURL LEFT AUTO SELECTED");
      break;
    case 4: 
      printf("%s\n","2 BALL CURL RIGHT AUTO SELECTED");
      break;
  }
}

void Robot::AutonomousPeriodic() 
{
  //execute the selected auto routine
  if(dAutoSelect == 1)  RunAuto_1();
  if(dAutoSelect == 2)  RunAuto_2();
  if(dAutoSelect == 3)  RunAuto_2();  //uses curve left stream for forward
  if(dAutoSelect == 4)  RunAuto_2();  //uses curve right stream for forward
}

void Robot::TeleopInit() 
{
  CurMode = 2;
  ClockStart = frc::Timer::GetFPGATimestamp();
  MatchStart = true;
  Climber->MoveSpinnersOUT();
  ClimbState = 0;
  if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbMode", ClimbMode);
}

void Robot::TeleopPeriodic() 
{
  //Drive arcade with one joystick - throttle up = shooter forward, throttle down = intake forward - extreme joystick
  if(constants::drive::kDriveWithArcade) Drive->DriveArcade2(Joystick0->GetRawAxis(1),Joystick0->GetRawAxis(0),0.15,true,Joystick0->GetRawAxis(3) < 0);
  
  //handle shooter 
  bool shootButton = Joystick0->GetRawButton(7) || Joystick0->GetRawButton(9) || Joystick0->GetRawButton(11);
  if(Joystick0->GetRawButtonPressed(7))  Shooter->Shooter_Speed = constants::shooter::kRPM_LowGoal; 
  if(Joystick0->GetRawButtonPressed(9))  Shooter->Shooter_Speed = constants::shooter::kRPM_9ft;     
  if(Joystick0->GetRawButtonPressed(11))  Shooter->Shooter_Speed = constants::shooter::kRPM_16ft;    
  Shooter->Periodic(shootButton,Shooter->Shooter_Speed);
  
  //handle intake  (also runs with shooter)
  Intake->Periodic(Joystick0->GetRawButton(1),shootButton); 

  //handle climber  
  if(Joystick1->GetRawButtonPressed(3) && ClimbState == 0)
  { 
    ClimbMode = 1;  //climb high
    Climber->SyncRotateSetpoint();  //bumpless transfer to auto climbing
    Climber->SyncExtendSetpoint();
    if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbMode", ClimbMode);
  }
  if(Joystick1->GetRawButtonPressed(4) && ClimbState >= 65) 
  {
    ClimbMode = 2;  //climb traverse
    ClimbState = 0; //reset state to climb again
    if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbMode", ClimbMode);
  }
  if(Joystick1->GetRawButtonPressed(5)) 
  {
    ClimbMode = 0;  //climb manual
    if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbMode", ClimbMode);
  }
  switch(ClimbMode)
  {
    case 1:
      Climb_High();
      break;
    case 2:
      Climb_High();
      break; 
    default:
      Climber->Periodic(Joystick1->GetRawAxis(1),Joystick1->GetRawButton(1),Joystick1->GetRawButton(8));
      ClimbState = 0;
      break;
  }
}

void Robot::TestInit() 
{
  CurMode = 3;
  MatchStart = true;
  Climber->SyncRotateSetpoint();
  Climber->SyncExtendSetpoint();
}

void Robot::TestPeriodic() 
{
  double stickY = Joystick0->GetRawAxis(1);  
  double armSpd = 0.0;
  double extSpd1 = 0.0;
  double extSpd2 = 0.0;
  double spnSpd1 = 0.0;
  double spnSpd2 = 0.0;
  //disable soft reverse limits for climber and intake
  //allows repositioning arms and intake if necessary
  Intake->EnableSoftReverseLimits(false);
  Climber->EnableSoftReverseLimits(false);
  
  //set all motors off
  Drive->Disable();
  Intake->Disable();
  Shooter->Disable();
  Climber->Disable();
  //test one motor
  switch(dTestSelect)
  {
    case 1:  //drive wheels
      Drive->TestDrive(stickY,stickY);
      break;
    case 2:  //intake position
      stickY = clamp2(stickY, -0.55, 0.55);  
      Intake->TestIntakePosition(-stickY);
      if(Joystick0->GetRawButtonPressed(1)) Intake->ZeroPosition();
      break;
    case 3: //intake wheels speed
      Intake->TestIntakeWheels(stickY);
      break;
    case 4: //feeder speed
      Shooter->TestFeeder(stickY);
      break;
    case 5: //shooter speed
      Shooter->TestShooter(stickY);
      break;
    case 6: //climber spinners position
      stickY = stickY/2;
      stickY = clamp2(stickY, -0.5, 0.5);  
      Climber->TestSpinners(-stickY);
      break;
    case 7: //climber rotate position
      stickY = stickY/3;
      //stickY = clamp2(stickY, -0.33, 0.33);  
      Climber->TestArmRotate(-stickY);
      break;
    case 8: //climber extend position
      stickY = stickY/2;
      stickY = clamp2(stickY, -0.5, 0.5);  
      Climber->TestArmExtend(-stickY);
      break;
    case 9: //climber spinner1 position
      stickY = stickY/2;
      stickY = clamp2(stickY, -0.5, 0.5);  
      Climber->TestSpinner1(-stickY);
      break;
    case 10: //climber spinner2 position
      stickY = stickY/2;
      stickY = clamp2(stickY, -0.5, 0.5);  
      Climber->TestSpinner2(-stickY);
      break;
    case 11: //climber extend1 position
      stickY = stickY/2;
      stickY = clamp2(stickY, -0.5, 0.5);  
      Climber->TestArmExtend1(-stickY);
      break;
    case 12: //climber extend2 position
      stickY = stickY/2;
      stickY = clamp2(stickY, -0.5, 0.5);  
      Climber->TestArmExtend2(-stickY);
      break;
    case 13: //climber position testing
      //rotating arms
      if(Joystick1->GetRawButtonPressed(7)) Climber->ArmRot_Setpoint = constants::climber::kStep7RotatePosition;
      if(Joystick1->GetRawButtonPressed(8)) Climber->ArmRot_Setpoint = constants::climber::kStep3RotatePosition;
      //extenders speed
      if(Joystick1->GetRawButtonPressed(11)) Climber->ArmExt_Setpoint = constants::climber::kStep7ExtendPosition; //retract
      if(Joystick1->GetRawButtonPressed(12)) Climber->ArmExt_Setpoint = constants::climber::kStep3ExtendPosition; //extend
      Climber->TestArmRotatePosition();
      Climber->TestArmSpinPosition(Joystick1->GetRawButton(9) || Joystick1->GetRawButton(10));
      Climber->TestArmExtendPosition();
      break;
    default: //climber can move using joystick 1
      //rotating arm speed
      armSpd = Joystick1->GetRawAxis(1)/3.0;
      armSpd = clamp2(armSpd, -0.5, 0.5);
      //spinners speed
      if(Joystick1->GetRawButton(9)) spnSpd1 = 0.3;
      if(Joystick1->GetRawButton(10)) spnSpd2 = 0.3;
      //extenders speed
      if(Joystick1->GetRawButton(11)) extSpd1 = -0.5; //retract only
      if(Joystick1->GetRawButton(12)) extSpd2 = -0.5; //retract only
      
      Climber->TestArmRotate(-armSpd);
      Climber->TestArmExtend1(extSpd1);
      Climber->TestArmExtend2(extSpd2);
      Climber->TestSpinner1(spnSpd1);
      Climber->TestSpinner2(spnSpd2);
      Drive->Disable();
      Intake->Disable();
      Shooter->Disable();
      break;
  }
}

void Robot::DisabledInit()
{
  //disable all systems
  Drive->Disable();
  Intake->Disable();
  Climber->Disable();
  Shooter->Disable();

  ModeTimer->Reset();

  //if coming from test mode, turn soft limits back on
  if(CurMode == 3) 
  {
    Intake->EnableSoftReverseLimits(true);
    Climber->EnableSoftReverseLimits(true);
  }
  
  //finally, set mode to 0 = disabled
  CurMode = 0;
}

void Robot::DisabledPeriodic()
{
  static int counter;
  //there is a disabled period of a few seconds between autonomous and teleop in a real match
  //reset MatchStart after 5 seconds of disabled period
  if(MatchStart && ModeTimer->AdvanceIfElapsed((units::time::second_t) 5)) MatchStart = false;
  
  if(!MatchStart)
  {
    counter++;
    if(counter >= 50) //1 sec
    {
      counter = 0;
      //check for faults
      Drive->CheckFaults();
      Intake->CheckFaults();
      Shooter->CheckFaults();
      Climber->CheckFaults();
    }
  }
}

void::Robot::RunAuto_1() //shoot high goal and reverse off of tarmac
{
    switch(AutoState)
    {
        case 0:
            AutoTimer->Reset();
            AutoState = 10;
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            break;
        case 10: //run shooter for 5 seconds
            ntBOSS->PutString("AutoStatus", "AUTO1_SHOOT");
            if(AutoTimer->AdvanceIfElapsed((units::time::second_t) 5))
            {
                AutoState = 20;
                if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            }
            break;
        case 20: //start drive control
            ntBOSS->PutString("AutoStatus", "AUTO1_REV5");
            Drive->AutoStart_Rev5();
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorLF_POS", Drive->GetLFDistance());
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorRF_POS", Drive->GetRFDistance());
            AutoState = 30;
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            break;
        case 30: //process drive control
            //look for end of profile
            if(!Drive->AutoIsRunning()) 
            {
                AutoState = 40;
                if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            }
            break;
        case 40:
            ntBOSS->PutString("AutoStatus", "AUTO1_DONE");
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorLF_POS", Drive->GetLFDistance());
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorRF_POS", Drive->GetRFDistance());
            Drive->Disable();
            break;
    }
    
    //handle shooter motors
    Shooter->Periodic(AutoState < 20,constants::shooter::kRPM_Auto1);

    //process drive in auto
    Drive->AutoPeriodic();

    Climber->Disable();
    Intake->Disable();
    Intake->Periodic(false, AutoState < 20);
}

void::Robot::RunAuto_2() //reverse to get 2nd ball, forward to shoot both
{
    switch(AutoState)
    {
        case 0:
            AutoState = 10;
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            break;
        case 10: //start drive control
            ntBOSS->PutString("AutoStatus", "AUTO2_REV5");
            Drive->AutoStart_Rev5();
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorLF_POS", Drive->GetLFDistance());
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorRF_POS", Drive->GetRFDistance());
            AutoState = 20;
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            break;
        case 20: //process drive control
            //look for end of profile
            if(!Drive->AutoIsRunning()) 
            {
                AutoState = 30;
                if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            }
            break;
        case 30:
            if(dAutoSelect == 2)
            {
              ntBOSS->PutString("AutoStatus", "AUTO2_FWD5");
              Drive->AutoStart_Fwd5();
            } 
            if(dAutoSelect == 3) 
            {
              ntBOSS->PutString("AutoStatus", "AUTO2_CURVELEFT");
              Drive->AutoStart_CurveLeft();
            }
            if(dAutoSelect == 4) 
            {
              ntBOSS->PutString("AutoStatus", "AUTO2_CURVERIGHT");
              Drive->AutoStart_CurveRight();
            }
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorLF_POS", Drive->GetLFDistance());
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorRF_POS", Drive->GetRFDistance());
            AutoState = 40;
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            break;
        case 40: //process drive control
            //look for end of profile
            if(!Drive->AutoIsRunning()) 
            {
                AutoState = 50;
                if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            }
            break;
        case 50:
            ntBOSS->PutString("AutoStatus", "AUTO2_SPINUP");
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorLF_POS", Drive->GetLFDistance());
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorRF_POS", Drive->GetRFDistance());
            Drive->Disable();
            AutoTimer->Reset();
            AutoState = 60;
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            break;
        case 60: //run shooter for 5 seconds
            ntBOSS->PutString("AutoStatus", "AUTO2_SHOOT");
            if(AutoTimer->AdvanceIfElapsed((units::time::second_t) 5))
            {
                AutoState = 70;
                if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("AutoState", AutoState);
            }
            break;
        case 70: 
            ntBOSS->PutString("AutoStatus", "AUTO2_DONE");
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorLF_POS", Drive->GetLFDistance());
            if(constants::kAutoLoggingEnabled) ntBOSS->PutNumber("MotorRF_POS", Drive->GetRFDistance());
            Drive->Disable();
            break;
    }
    
    //handle intake motors
    Intake->Periodic(AutoState < 30, AutoState == 60);
    
    //handle shooter motors
    Shooter->Periodic(AutoState == 60,constants::shooter::kRPM_Auto2);

    //process drive in auto
    Drive->AutoPeriodic();

    Climber->Disable();
}

void Robot::Climb_High() //climb the high bar or traverse bar
{
  static int printCount;
  static double stepStart;
  
    printCount++;
    double climbTime = (printCount*20)/1000;
    switch(ClimbState)
    {
        case 0:
            printCount = 1;
            ClimbState = 5;
            break;
        case 5: //STEP 1 - rotate spinners IN
            stepStart = (printCount*20)/1000;
            Climber->MoveSpinnersIN();
            ClimbState = 10;
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 10: 
            if(Climber->SpinnersAreHooked()) 
            {
              ClimbState = 15;
              if(constants::kClimberLoggingEnabled) printf("%s: %f secs\n","STEP 1 - Spinners are HOOKED",climbTime - stepStart);
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 15: //STEP 2 - extend a little 
            stepStart = (printCount*20)/1000;
            Climber->ArmExt_Setpoint = constants::climber::kStep2ExtendPosition;
            ClimbState = 20;
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 20:
            if(Climber->ExtendersAreAtPosition()) 
            {
              ClimbState = 25;
              if(constants::kClimberLoggingEnabled) printf("%s: %f secs\n","STEP 2 - Clear Extender Hooks",climbTime - stepStart);
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 25: //STEP 3 a - rotate arms forward
            stepStart = (printCount*20)/1000;
            Climber->ArmRot_Setpoint = constants::climber::kStep3RotatePosition;
            ClimbState = 27;
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 27: 
            if(Climber->RotatingArmsAtPosition())
            {
              ClimbState = 28;
              if(constants::kClimberLoggingEnabled) printf("%s: %f secs\n","STEP 3a - Arms Rotated Forward",climbTime - stepStart);
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 28: //STEP 3 b - full extend
            stepStart = (printCount*20)/1000;
            Climber->ArmExt_Setpoint = constants::climber::kStep3ExtendPosition;
            ClimbState = 30;
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 30:
            if(Climber->ExtendersAreAtPosition())
            {
              ClimbState = 35;
              if(constants::kClimberLoggingEnabled) printf("%s: %f secs\n","STEP 3b - Hooks Extended Out",climbTime - stepStart);
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 35: //STEP 4 - rotate arms back towards high bar
            stepStart = (printCount*20)/1000;
            Climber->ArmRot_Setpoint = constants::climber::kStep4RotatePosition;
            ClimbState = 40;
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 40:
            if(Climber->RotatingArmsAtPosition())
            {
              ClimbState = 45;
              if(constants::kClimberLoggingEnabled) printf("%s: %f secs\n","STEP 4 - Arms Rotated to High Bar",climbTime - stepStart);
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 45: //STEP 5 - retract hooks to grab high bar
            stepStart = (printCount*20)/1000;
            Climber->ArmExt_Setpoint = constants::climber::kStep5ExtendPosition;
            ClimbState = 50;
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 50:
            if(Climber->ExtendersAreAtPosition())
            {
              ClimbState = 55;
              if(constants::kClimberLoggingEnabled) printf("%s: %f secs\n","STEP 5 - Extenders Retracted on High Bar",climbTime - stepStart);
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 55: //STEP 6 - rotate spinners OUT
            stepStart = (printCount*20)/1000;
            Climber->MoveSpinnersOUT();
            ClimbState = 60;
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 60: 
            if(Climber->SpinnersAreNotHooked()) 
            {
              ClimbState = 65;
              if(constants::kClimberLoggingEnabled) printf("%s: %f secs\n","STEP 6 - Spinners are NOT HOOKED",climbTime - stepStart);
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 65: //STEP 7 - pull up on high bar and rotate back to vertical
            stepStart = (printCount*20)/1000;
            Climber->ArmExt_Setpoint = constants::climber::kStep7ExtendPosition;
            Climber->ArmRot_Setpoint = constants::climber::kStep7RotatePosition;
            ClimbState = 70;
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 70:
            if(Climber->RotatingArmsAtPosition())
            {
              ClimbState = 100;
              if(constants::kClimberLoggingEnabled) printf("%s: %f secs\n","STEP 7 - Rotate to Vertical",climbTime - stepStart);
              if(constants::kClimberLoggingEnabled) printf("%s: %f secs Overall\n","CLIMB_HIGH - Complete",climbTime);
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
    }
    Climber->AutoPeriodic();
    Drive->Disable();
    Intake->Disable();
    Shooter->Disable();
}

void Robot::Climb_High2() //extend and rotate together in step 3
{
  static int counter;
  static int printCount;
  bool extIsDone, armIsDone;
    printCount++;
    switch(ClimbState)
    {
        case 0:
            ClimbState = 5;
            if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Start");
            break;
        case 5: //STEP 1 - rotate spinners IN
            Climber->MoveSpinnersIN();
            ClimbState = 10;
            if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Move Spinners IN");
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 10: 
            if(Climber->SpinnersAreHooked()) 
            {
              ClimbState = 15;
              if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Spinners are HOOKED");
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 15: //STEP 2 - extend a little 
            Climber->ArmExt_Setpoint = constants::climber::kStep2ExtendPosition;
            ClimbState = 20;
            if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Extend to clear hooks");
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 20:
            if(Climber->ExtendersAreAtPosition()) 
            {
              ClimbState = 25;
              counter = 0;
              if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Extend hooks are clear");
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 25: //STEP 3 - rotate arms forward and full extend
            Climber->ArmRot_Setpoint = constants::climber::kStep3RotatePosition;
            if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Arms released to rotate");
            counter++;
            if(counter >= 50) //about 1 sec delay
            {
              counter = 0;
              Climber->ArmExt_Setpoint = constants::climber::kStep3ExtendPosition;
              if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Extenders released to extend");
              ClimbState = 30;
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 30:
            extIsDone = Climber->ExtendersAreAtPosition();
            if(constants::kClimberLoggingEnabled && extIsDone) printf("%i: %s\n",printCount,"CLIMB_HIGH (30) - extDone = true");
            armIsDone = Climber->RotatingArmsAtPosition();
            if(constants::kClimberLoggingEnabled && armIsDone) printf("%i: %s\n",printCount,"CLIMB_HIGH (30) - armDone = true");
            //if(Climber->ExtendersAreAtPosition() && Climber->RotatingArmsAtPosition())
            if(extIsDone && armIsDone)
            {
              ClimbState = 35;
              if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Both Arms and Extend at Position");
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 35: //STEP 4 - rotate arms back towards high bar
            Climber->ArmRot_Setpoint = constants::climber::kStep4RotatePosition;
            ClimbState = 40;
            if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - rotating up to bar");
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 40:
            if(Climber->RotatingArmsAtPosition())
            {
              ClimbState = 45;
              if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Arms at high bar");
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 45: //STEP 5 - retract hooks to grab high bar
            Climber->ArmExt_Setpoint = constants::climber::kStep5ExtendPosition;
            ClimbState = 50;
            if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - retracting to hook high bar");
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 50:
            if(Climber->ExtendersAreAtPosition())
            {
              ClimbState = 55;
              if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Extenders are at position");
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 55: //STEP 6 - rotate spinners OUT
            Climber->MoveSpinnersOUT();
            ClimbState = 60;
            if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Move spinners to OUT");
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 60: 
            if(Climber->SpinnersAreNotHooked()) 
            {
              ClimbState = 65;
              if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Spinners are not HOOKED");
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
        case 65: //STEP 7 - pull up on high bar and rotate back to vertical
            Climber->ArmExt_Setpoint = constants::climber::kStep7ExtendPosition;
            Climber->ArmRot_Setpoint = constants::climber::kStep7RotatePosition;
            ClimbState = 70;
            if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - pulling up on bar and rotating to vertical");
            if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            break;
        case 70:
            //if(Climber->ExtendersAreAtPosition() && Climber->RotatingArmsAtPosition())
            if(Climber->RotatingArmsAtPosition())
            {
              ClimbState = 100;
              if(constants::kClimberLoggingEnabled) printf("%i: %s\n",printCount,"CLIMB_HIGH - Both arms and extenders are at position");
              double climbTime = (printCount*20)/1000;
              if(constants::kClimberLoggingEnabled) printf("%s: %f seconds\n",printCount,"CLIMB_HIGH - Complete",climbTime);
              if(constants::kClimberLoggingEnabled) ntBOSS->PutNumber("ClimbState", ClimbState);
            }
            break;
    }
    Climber->AutoPeriodic();
    Drive->Disable();
    Intake->Disable();
    Shooter->Disable();
}

void Robot::LimeLight_TargetMode()
{
  if(constants::kLimeLightEnabled) 
  {
    ntCameraData->PutNumber("ledMode",3);  //led's on
    ntCameraData->PutNumber("camMode",0);  //target processing
  }
}

void Robot::LimeLight_CameraMode()
{
  if(constants::kLimeLightEnabled) 
  {
    ntCameraData->PutNumber("ledMode",1);  //led's off
    ntCameraData->PutNumber("camMode",1);  //regular camera mode
  }
}

double Robot::LimeLight_GetDistance()
{
  double targetDistance = -1.0;
  if(constants::kLimeLightEnabled) 
  {
    //get vision target info from limelight - use moving average filters
    double raw = ntCameraData->GetNumber("ty",0.0);
    VisionTargetY = lpfVTY * raw + ((1-lpfVTY)*VisionTargetY);
    raw = ntCameraData->GetNumber("tv",0.0);
    VisionTargetV = lpfVTV * raw + ((1-lpfVTV)*VisionTargetV);
    bool VisionTargetValid = VisionTargetV > 0.8;
    if(VisionTargetY <= 0.0 || VisionTargetY > 24.85) VisionTargetValid = false;
    if(VisionTargetValid)
    {
      if(VisionTargetY > 0.0) 
      {
        //distance = (TargetHeight - CameraHeight) * tan((TargetAngle+CameraAngle)*0.0174533)  -tan expects radians - multiply by 0.0174533
        targetDistance = (constants::limelight::TargetHeight - constants::limelight::CameraHeight) / tan((VisionTargetY+constants::limelight::CameraAngle)*0.0174533);
        targetDistance = clamp2(targetDistance,constants::limelight::MinDistance,constants::limelight::MaxDistance);
      }
    }
  }
    static int counter = 0;
    counter++;
    if(counter >= 13)
    {
      counter = 0;
      ntBOSS->PutNumber("Target_Y", VisionTargetY);
      ntBOSS->PutNumber("Target_V", VisionTargetV);
      ntBOSS->PutNumber("Target_Dist", targetDistance);
    }
  return targetDistance;
}


#ifndef RUNNING_FRC_TESTS
int main() { return frc::StartRobot<Robot>(); }
#endif