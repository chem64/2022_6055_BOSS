#include "Shooter.h"
using namespace frc;

enum Constants {kSlotIdx = 0, kPIDLoopIdx = 0, kTimeoutMs = 50};

void ShooterClass::Init()
{
  SupplyCurrentLimitConfiguration shooterSCLC = SupplyCurrentLimitConfiguration{true,constants::shooter::kSupplyCurrentLimit,constants::shooter::kPeakCurrentLimit,constants::shooter::kPeakCurrentDuration};
  //Falcon500, 8" wheels
  MotorShooter1 = new WPI_TalonFX(constants::shooter::kMotorShooter1_ID); //CAN
  MotorShooter1->ConfigFactoryDefault(kTimeoutMs);
  MotorShooter1->ConfigSelectedFeedbackSensor(FeedbackDevice::IntegratedSensor, 0, kTimeoutMs);
  MotorShooter1->SetInverted(true);
  MotorShooter1->ConfigNeutralDeadband(0.04, kTimeoutMs);
  MotorShooter1->SetNeutralMode(NeutralMode::Coast);
  MotorShooter1->ConfigNominalOutputForward(0, kTimeoutMs);
  MotorShooter1->ConfigNominalOutputReverse(0, kTimeoutMs);
  MotorShooter1->ConfigPeakOutputForward(1, kTimeoutMs);
  //lockout reverse movement
  MotorShooter1->ConfigPeakOutputReverse(0, kTimeoutMs);
  MotorShooter1->Config_kF(0, constants::shooter::kF, kTimeoutMs);
  MotorShooter1->Config_kP(0, constants::shooter::kP, kTimeoutMs);
  MotorShooter1->Config_kI(0, constants::shooter::kI, kTimeoutMs);
  MotorShooter1->Config_kD(0, constants::shooter::kD, kTimeoutMs);
  MotorShooter1->Config_IntegralZone(0, 400, kTimeoutMs);
  MotorShooter1->ConfigClosedLoopPeakOutput(0,1.0,kTimeoutMs);
  MotorShooter1->ConfigSupplyCurrentLimit(shooterSCLC);//CURRENT_LIMITING
  MotorShooter1->SetStatusFramePeriod(StatusFrameEnhanced::Status_13_Base_PIDF0, 10, 10);
  //MotorShooter1->SetStatusFramePeriod(statusframeEnhanced::Status_10_MotionMagic, 10, 10);
  MotorShooter1->ConfigClosedloopRamp(constants::shooter::kClosedLoopRamp,kTimeoutMs);
  MotorShooter1->ConfigVoltageCompSaturation(constants::shooter::kVoltageCompSaturation);
  MotorShooter1->EnableVoltageCompensation(true);
  MotorShooter1->SetSafetyEnabled(false);

  //Falcon500, 8" wheels
  MotorShooter2 = new WPI_TalonFX(constants::shooter::kMotorShooter2_ID); //CAN
  MotorShooter2->ConfigFactoryDefault(kTimeoutMs);
  MotorShooter2->ConfigSelectedFeedbackSensor(FeedbackDevice::IntegratedSensor, 0, kTimeoutMs);
  MotorShooter2->SetInverted(false);
  MotorShooter2->ConfigNeutralDeadband(0.04, kTimeoutMs);
  MotorShooter2->SetNeutralMode(NeutralMode::Coast);
  MotorShooter2->ConfigNominalOutputForward(0, kTimeoutMs);
  MotorShooter2->ConfigNominalOutputReverse(0, kTimeoutMs);
  MotorShooter2->ConfigPeakOutputForward(1, kTimeoutMs);
  //lockout reverse movement
  MotorShooter2->ConfigPeakOutputReverse(0, kTimeoutMs);
  MotorShooter2->Config_kF(0, constants::shooter::kF, kTimeoutMs);
  MotorShooter2->Config_kP(0, constants::shooter::kP, kTimeoutMs);
  MotorShooter2->Config_kI(0, constants::shooter::kI, kTimeoutMs);
  MotorShooter2->Config_kD(0, constants::shooter::kD, kTimeoutMs);
  MotorShooter2->Config_IntegralZone(0, 400, kTimeoutMs);
  MotorShooter2->ConfigClosedLoopPeakOutput(0,1.0,kTimeoutMs);
  MotorShooter2->ConfigSupplyCurrentLimit(shooterSCLC);//CURRENT_LIMITING
  MotorShooter2->SetStatusFramePeriod(StatusFrameEnhanced::Status_13_Base_PIDF0, 10, 10);
  //MotorShooter1->SetStatusFramePeriod(statusframeEnhanced::Status_10_MotionMagic, 10, 10);
  MotorShooter2->ConfigClosedloopRamp(constants::shooter::kClosedLoopRamp,kTimeoutMs);
  MotorShooter2->ConfigVoltageCompSaturation(constants::shooter::kVoltageCompSaturation);
  MotorShooter2->EnableVoltageCompensation(true);
  MotorShooter2->SetSafetyEnabled(false);

  //775 motor  shaft faces right - turns CW ????
  MotorFeeder = new WPI_TalonSRX(constants::shooter::kMotorFeeder_ID);//CAN
  MotorFeeder->ConfigFactoryDefault(kTimeoutMs);
  MotorFeeder->ConfigOpenloopRamp(1.0, kTimeoutMs);
  MotorFeeder->SetNeutralMode(NeutralMode::Brake);
  MotorFeeder->SetSensorPhase(false);
  MotorFeeder->SetInverted(true);
  MotorFeeder->SetSafetyEnabled(false);
  MotorFeeder->ConfigPeakCurrentLimit(constants::shooter::kPeakCurrentLimit, kTimeoutMs);
  MotorFeeder->ConfigPeakCurrentDuration(constants::shooter::kPeakCurrentDuration, kTimeoutMs);
  MotorFeeder->ConfigContinuousCurrentLimit(constants::shooter::kContinuousCurrentLimit, kTimeoutMs);
  MotorFeeder->EnableCurrentLimit(true);
  if(!constants::climber::kArmRot_UsePlanetaryGearbox)
  {
    //setup analog potentiometer to feed rotation arm position through this sensor
    MotorFeeder->ConfigSelectedFeedbackSensor(FeedbackDevice::Analog,0,kTimeoutMs);
    //speed up feedback frames for analog sensor
    MotorFeeder->SetStatusFramePeriod(StatusFrameEnhanced::Status_2_Feedback0, 10, 10);
  }
  MotorFeeder->ConfigVoltageCompSaturation(12.5);
  MotorFeeder->EnableVoltageCompensation(true);

  FeedTimer = new Timer();
  FeedTimer->Start();

  //BOSS dashboard on Drive Station computer
  ntBOSS = nt::NetworkTableInstance::GetDefault().GetTable("dashBOSS");
  if(constants::kShooterLoggingEnabled) 
  {
    ntBOSS->PutNumber("Shooter_Speed",Shooter_Speed);
    ntBOSS->PutNumber("Feeder_Speed",Feeder_Speed);
  }
}

void ShooterClass::Periodic(bool button, double rpm)
{
  if(button) 
  {
    if(!buttonFlag)//reset timer when button pressed
    {
      buttonFlag = true;
      FeedTimer->Reset();
    }
    //run shooter while button pressed
    MotorShooter1->Set(ControlMode::Velocity, rpm * constants::shooter::kRPMToUnits);
    MotorShooter2->Set(ControlMode::Velocity, rpm * constants::shooter::kRPMToUnits);
    //run feeder after delay for shooter spinup
    if(FeedTimer->AdvanceIfElapsed((units::time::second_t) constants::shooter::kFeederDelaySecs))
    {
      MotorFeeder->Set(ControlMode::PercentOutput, Feeder_Speed);  
    }
  }
  else 
  {
    buttonFlag = false;
    MotorShooter1->Set(ControlMode::PercentOutput, 0.0);
    MotorShooter2->Set(ControlMode::PercentOutput, 0.0);
    MotorFeeder->Set(ControlMode::PercentOutput, 0.0);
  }

  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    if(constants::kShooterLoggingEnabled) 
    {
      ntBOSS->PutNumber("Shooter_RPM", MotorShooter1->GetSelectedSensorVelocity(0) * constants::shooter::kUnitsToRPM);
      ntBOSS->PutNumber("Shooter_TGT",MotorShooter1->GetClosedLoopTarget(0) * constants::shooter::kUnitsToRPM);
    }
  }
}

void ShooterClass::TestShooter(double speed)
{
  //MotorShooter1->Set(ControlMode::PercentOutput, speed);
  MotorShooter1->Set(ControlMode::Velocity, (std::fabs(speed) * 6380.0) * constants::shooter::kRPMToUnits);
  MotorShooter2->Set(ControlMode::Velocity, (std::fabs(speed) * 6380.0) * constants::shooter::kRPMToUnits);
  CalcShooterKF();
  if(constants::kShooterLoggingEnabled) 
  {
    static int counter = 0;
    counter++;
    if(counter >= 13)
    {
      counter = 0;
      ntBOSS->PutNumber("Shooter_RPM", MotorShooter1->GetSelectedSensorVelocity(0) * constants::shooter::kUnitsToRPM);
    }
  }
}

void ShooterClass::ClearShooterKF()
{
  Shooter1MaxUnits = 0;
  Shooter2MaxUnits = 0;
}

void ShooterClass::CalcShooterKF()
{
  if(constants::kShooterLoggingEnabled) 
  {
    Shooter1MaxUnits = std::max(MotorShooter1->GetSelectedSensorVelocity(0),Shooter1MaxUnits);
    Shooter2MaxUnits = std::max(MotorShooter2->GetSelectedSensorVelocity(0),Shooter2MaxUnits);
    double kf1 = 1023.0/Shooter1MaxUnits;
    double kf2 = 1023.0/Shooter2MaxUnits;
    
    static int counter = 0;
    counter++;
    if(counter >= 13)
    {
      counter = 0;
      ntBOSS->PutNumber("Shooter1_KF", kf1);
      ntBOSS->PutNumber("Shooter2_KF", kf2);
      ntBOSS->PutNumber("Shooter1_MU", Shooter1MaxUnits);
      ntBOSS->PutNumber("Shooter2_MU", Shooter2MaxUnits);
    }
  }
}

void ShooterClass::TestFeeder(double speed)
{
  MotorFeeder->Set(ControlMode::PercentOutput, speed);
}

void ShooterClass::Disable()
{
  MotorShooter1->Set(ControlMode::PercentOutput, 0.0);
  MotorShooter2->Set(ControlMode::PercentOutput, 0.0);
  MotorFeeder->Set(ControlMode::PercentOutput,0.0);
}

double ShooterClass::GetShooterRPM()
{
  return MotorShooter2->GetSelectedSensorVelocity(0) * constants::shooter::kUnitsToRPM;
}

void ShooterClass::CheckFaults()
{
  FX_CheckFaults(MotorShooter1,"SHOOTER 1",6);
  FX_CheckFaults(MotorShooter2,"SHOOTER 2",7);
  SRX_CheckFaults(MotorFeeder,"FEEDER",14);
  ntBOSS->PutNumber("ShooterFault", ShooterFault);
}

void ShooterClass::ClearStickyFaults()
{
  MotorShooter1->ClearStickyFaults();
  MotorShooter2->ClearStickyFaults();
  MotorFeeder->ClearStickyFaults();
}

void ShooterClass::FX_CheckFaults(WPI_TalonFX *Motor,std::string name,short bit)
{
  Faults f;
  StickyFaults sf;
  
  ShooterFault = clearBit(ShooterFault,bit);
  Motor->GetFaults(f);
  Motor->GetStickyFaults(sf);
  if(f.ResetDuringEn || f.SensorOutOfPhase || f.UnderVoltage)
  {
    ShooterFault = setBit(ShooterFault,bit);
    if(f.ResetDuringEn) printf("%s: %s\n",name.c_str(),"RESET DURING ENABLE");
    if(f.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"OUT OF PHASE");
    if(f.UnderVoltage) printf("%s: %s\n",name.c_str(),"UNDER VOLTAGE");
  }
  if(sf.ResetDuringEn || sf.SensorOutOfPhase || sf.UnderVoltage)
  {
    ShooterFault = setBit(ShooterFault,bit);  
    if(sf.ResetDuringEn) printf("%s: %s\n",name.c_str(),"STICKY RESET DURING ENABLE");
    if(sf.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"STICKY OUT OF PHASE");
    if(sf.UnderVoltage) printf("%s: %s\n",name.c_str(),"STICKY UNDER VOLTAGE");
  }
}

void ShooterClass::SRX_CheckFaults(WPI_TalonSRX *Motor,std::string name,short bit)
{
  Faults f;
  StickyFaults sf;
  
  ShooterFault = clearBit(ShooterFault,bit);
  Motor->GetFaults(f);
  Motor->GetStickyFaults(sf);
  if(f.ResetDuringEn || f.SensorOutOfPhase || f.UnderVoltage)
  {
    ShooterFault = setBit(ShooterFault,bit);
    if(f.ResetDuringEn) printf("%s: %s\n",name.c_str(),"RESET DURING ENABLE");
    if(f.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"OUT OF PHASE");
    if(f.UnderVoltage) printf("%s: %s\n",name.c_str(),"UNDER VOLTAGE");
  }
  if(sf.ResetDuringEn || sf.SensorOutOfPhase || sf.UnderVoltage)
  {
    ShooterFault = setBit(ShooterFault,bit);  
    if(sf.ResetDuringEn) printf("%s: %s\n",name.c_str(),"STICKY RESET DURING ENABLE");
    if(sf.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"STICKY OUT OF PHASE");
    if(sf.UnderVoltage) printf("%s: %s\n",name.c_str(),"STICKY UNDER VOLTAGE");
  }
}

void ShooterClass::GetMaxAmps(bool SendToDash)
{
  double tmp;

  if(constants::kShooterLoggingEnabled)
  {
    tmp = MotorShooter1->GetOutputCurrent();  
    if(tmp > Shooter1MaxAmps) Shooter1MaxAmps = tmp;
    tmp = MotorShooter2->GetOutputCurrent();  
    if(tmp > Shooter2MaxAmps) Shooter2MaxAmps = tmp;
    tmp = MotorFeeder->GetOutputCurrent();
    if(tmp > FeederMaxAmps) FeederMaxAmps = tmp;
    if(SendToDash)
    {
      ntBOSS->PutNumber("Shooter1_AMP",Shooter1MaxAmps);
      ntBOSS->PutNumber("Shooter2_AMP",Shooter2MaxAmps);
      ntBOSS->PutNumber("Feeder_AMP",FeederMaxAmps);
    }
  }
}

void ShooterClass::ResetMaxAmps()
{
  Shooter1MaxAmps = 0;
  Shooter2MaxAmps = 0;
  FeederMaxAmps = 0;
}