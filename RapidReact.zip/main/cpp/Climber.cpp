#include "Climber.h"
using namespace frc;

enum Constants {kSlotIdx = 0, kPIDLoopIdx = 0, kTimeoutMs = 50};


void ClimberClass::Init()
{
  SupplyCurrentLimitConfiguration armSCLC = SupplyCurrentLimitConfiguration{true,constants::climber::kSupplyCurrentLimit,constants::climber::kPeakCurrentLimit,constants::climber::kPeakCurrentDuration};

  //3:33 reduction after encoder  - turns CCW
  MotorArmStat1 = new WPI_TalonSRX(constants::climber::kMotorArmStat1_ID);//CAN
  MotorArmStat1->ConfigFactoryDefault(kTimeoutMs);
  MotorArmStat1->ConfigSelectedFeedbackSensor(FeedbackDevice::CTRE_MagEncoder_Relative, 0,kTimeoutMs);
  MotorArmStat1->SetNeutralMode(NeutralMode::Brake);
  MotorArmStat1->SetSensorPhase(false);
  MotorArmStat1->SetInverted(true);
  MotorArmStat1->SetSafetyEnabled(false);
  MotorArmStat1->ConfigPeakCurrentLimit(constants::climber::kPeakCurrentLimit, kTimeoutMs);
  MotorArmStat1->ConfigPeakCurrentDuration(constants::climber::kPeakCurrentDuration, kTimeoutMs);
  MotorArmStat1->ConfigContinuousCurrentLimit(constants::climber::kContinuousCurrentLimit, kTimeoutMs);
  MotorArmStat1->EnableCurrentLimit(true);
  MotorArmStat1->SetStatusFramePeriod(StatusFrameEnhanced::Status_13_Base_PIDF0, 10, 10);
  MotorArmStat1->SetStatusFramePeriod(StatusFrameEnhanced::Status_10_MotionMagic, 10, 10);
  MotorArmStat1->ConfigNominalOutputForward(0, kTimeoutMs);
  MotorArmStat1->ConfigNominalOutputReverse(0, kTimeoutMs);
  MotorArmStat1->ConfigPeakOutputForward(1, kTimeoutMs);
  MotorArmStat1->ConfigPeakOutputReverse(0, kTimeoutMs);  //don't allow reverse
  MotorArmStat1->Config_kF(0, constants::climber::kSpin_F, kTimeoutMs);
  MotorArmStat1->Config_kP(0, constants::climber::kSpin_P, kTimeoutMs);
  MotorArmStat1->Config_kI(0, constants::climber::kSpin_I, kTimeoutMs);
  MotorArmStat1->Config_kD(0, constants::climber::kSpin_D, kTimeoutMs);
  MotorArmStat1->Config_IntegralZone(0, 400, kTimeoutMs);
  MotorArmStat1->ConfigAllowableClosedloopError(0,10,kTimeoutMs);  
  MotorArmStat1->ConfigMotionCruiseVelocity(constants::climber::kSpin_MotionCruiseVelocity, kTimeoutMs);
  MotorArmStat1->ConfigMotionAcceleration(constants::climber::kSpin_MotionAcceleration, kTimeoutMs);
  MotorArmStat1->ConfigMotionSCurveStrength(constants::climber::kSpin_MotionSCurveStrength, kTimeoutMs);
  MotorArmStat1->ConfigVoltageCompSaturation(constants::climber::kVoltageCompSaturation);
  MotorArmStat1->EnableVoltageCompensation(true);
  
  //turns CW
  MotorArmStat2 = new WPI_TalonSRX(constants::climber::kMotorArmStat2_ID);//CAN
  MotorArmStat2->ConfigFactoryDefault(kTimeoutMs);
  MotorArmStat2->ConfigSelectedFeedbackSensor(FeedbackDevice::CTRE_MagEncoder_Relative, 0,kTimeoutMs);
  MotorArmStat2->SetNeutralMode(NeutralMode::Brake);
  MotorArmStat2->SetSensorPhase(false);
  MotorArmStat2->SetInverted(false);
  MotorArmStat2->SetSafetyEnabled(false);
  MotorArmStat2->ConfigPeakCurrentLimit(constants::climber::kPeakCurrentLimit, kTimeoutMs);
  MotorArmStat2->ConfigPeakCurrentDuration(constants::climber::kPeakCurrentDuration, kTimeoutMs);
  MotorArmStat2->ConfigContinuousCurrentLimit(constants::climber::kContinuousCurrentLimit, kTimeoutMs);
  MotorArmStat2->EnableCurrentLimit(true);
  MotorArmStat2->SetStatusFramePeriod(StatusFrameEnhanced::Status_13_Base_PIDF0, 10, 10);
  MotorArmStat2->SetStatusFramePeriod(StatusFrameEnhanced::Status_10_MotionMagic, 10, 10);
  MotorArmStat2->ConfigNominalOutputForward(0, kTimeoutMs);
  MotorArmStat2->ConfigNominalOutputReverse(0, kTimeoutMs);
  MotorArmStat2->ConfigPeakOutputForward(1, kTimeoutMs);
  MotorArmStat2->ConfigPeakOutputReverse(0, kTimeoutMs);  //don't allow reverse
  MotorArmStat2->Config_kF(0, constants::climber::kSpin_F, kTimeoutMs);
  MotorArmStat2->Config_kP(0, constants::climber::kSpin_P, kTimeoutMs);
  MotorArmStat2->Config_kI(0, constants::climber::kSpin_I, kTimeoutMs);
  MotorArmStat2->Config_kD(0, constants::climber::kSpin_D, kTimeoutMs);
  MotorArmStat2->Config_IntegralZone(0, 400, kTimeoutMs);
  MotorArmStat2->ConfigAllowableClosedloopError(0,10,kTimeoutMs);  
  MotorArmStat2->ConfigMotionCruiseVelocity(constants::climber::kSpin_MotionCruiseVelocity, kTimeoutMs);
  MotorArmStat2->ConfigMotionAcceleration(constants::climber::kSpin_MotionAcceleration, kTimeoutMs);
  MotorArmStat2->ConfigMotionSCurveStrength(constants::climber::kSpin_MotionSCurveStrength, kTimeoutMs);
  MotorArmStat2->ConfigVoltageCompSaturation(constants::climber::kVoltageCompSaturation);
  MotorArmStat2->EnableVoltageCompensation(true);
  
  //turns CCW
  MotorArmRot1_Extend = new WPI_TalonSRX(constants::climber::kMotorArmRot1_Extend_ID);//CAN
  MotorArmRot1_Extend->ConfigFactoryDefault(kTimeoutMs);
  MotorArmRot1_Extend->ConfigSelectedFeedbackSensor(FeedbackDevice::CTRE_MagEncoder_Relative, 0,kTimeoutMs);
  MotorArmRot1_Extend->SetNeutralMode(NeutralMode::Brake);
  MotorArmRot1_Extend->SetSensorPhase(false);
  MotorArmRot1_Extend->SetInverted(false);
  MotorArmRot1_Extend->SetSafetyEnabled(false);
  MotorArmRot1_Extend->ConfigPeakCurrentLimit(constants::climber::kPeakCurrentLimit, kTimeoutMs);
  MotorArmRot1_Extend->ConfigPeakCurrentDuration(constants::climber::kPeakCurrentDuration, kTimeoutMs);
  MotorArmRot1_Extend->ConfigContinuousCurrentLimit(constants::climber::kContinuousCurrentLimit, kTimeoutMs);
  MotorArmRot1_Extend->EnableCurrentLimit(true);
  MotorArmRot1_Extend->SetStatusFramePeriod(StatusFrameEnhanced::Status_13_Base_PIDF0, 10, 10);
  MotorArmRot1_Extend->SetStatusFramePeriod(StatusFrameEnhanced::Status_10_MotionMagic, 10, 10);
  MotorArmRot1_Extend->ConfigNominalOutputForward(0, kTimeoutMs);
  MotorArmRot1_Extend->ConfigNominalOutputReverse(0, kTimeoutMs);
  MotorArmRot1_Extend->ConfigPeakOutputForward(1, kTimeoutMs);
  MotorArmRot1_Extend->ConfigPeakOutputReverse(-1, kTimeoutMs);
  MotorArmRot1_Extend->Config_kF(0, constants::climber::kArmExt_F, kTimeoutMs);
  MotorArmRot1_Extend->Config_kP(0, constants::climber::kArmExt_P, kTimeoutMs);
  MotorArmRot1_Extend->Config_kI(0, constants::climber::kArmExt_I, kTimeoutMs);
  MotorArmRot1_Extend->Config_kD(0, constants::climber::kArmExt_D, kTimeoutMs);
  MotorArmRot1_Extend->Config_IntegralZone(0, 400, kTimeoutMs);
  MotorArmRot1_Extend->ConfigAllowableClosedloopError(0,constants::climber::kArmExt_AllowableError,kTimeoutMs); 
  MotorArmRot1_Extend->ConfigMotionCruiseVelocity(constants::climber::kArmExt_MotionCruiseVelocity, kTimeoutMs);
  MotorArmRot1_Extend->ConfigMotionAcceleration(constants::climber::kArmExt_MotionAcceleration, kTimeoutMs);
  MotorArmRot1_Extend->ConfigMotionSCurveStrength(constants::climber::kArmExt_MotionSCurveStrength, kTimeoutMs);
  MotorArmRot1_Extend->ConfigVoltageCompSaturation(constants::climber::kVoltageCompSaturation);
  MotorArmRot1_Extend->EnableVoltageCompensation(true);
  MotorArmRot1_Extend->ConfigForwardSoftLimitThreshold(constants::climber::kArmExt_ExtendLimit);
  MotorArmRot1_Extend->ConfigReverseSoftLimitThreshold(constants::climber::kArmExt_RetractLimit);
  MotorArmRot1_Extend->ConfigForwardSoftLimitEnable(true);
  MotorArmRot1_Extend->ConfigReverseSoftLimitEnable(true);

  //turns CW
  MotorArmRot2_Extend = new WPI_TalonSRX(constants::climber::kMotorArmRot2_Extend_ID);//CAN
  MotorArmRot2_Extend->ConfigFactoryDefault(kTimeoutMs);
  MotorArmRot2_Extend->ConfigSelectedFeedbackSensor(FeedbackDevice::CTRE_MagEncoder_Relative, 0,kTimeoutMs);
  MotorArmRot2_Extend->SetNeutralMode(NeutralMode::Brake);
  MotorArmRot2_Extend->SetSensorPhase(false);
  MotorArmRot2_Extend->SetInverted(true);
  MotorArmRot2_Extend->SetSafetyEnabled(false);
  MotorArmRot2_Extend->ConfigPeakCurrentLimit(constants::climber::kPeakCurrentLimit, kTimeoutMs);
  MotorArmRot2_Extend->ConfigPeakCurrentDuration(constants::climber::kPeakCurrentDuration, kTimeoutMs);
  MotorArmRot2_Extend->ConfigContinuousCurrentLimit(constants::climber::kContinuousCurrentLimit, kTimeoutMs);
  MotorArmRot2_Extend->EnableCurrentLimit(true);
  MotorArmRot2_Extend->SetStatusFramePeriod(StatusFrameEnhanced::Status_13_Base_PIDF0, 10, 10);
  MotorArmRot2_Extend->SetStatusFramePeriod(StatusFrameEnhanced::Status_10_MotionMagic, 10, 10);
  MotorArmRot2_Extend->ConfigNominalOutputForward(0, kTimeoutMs);
  MotorArmRot2_Extend->ConfigNominalOutputReverse(0, kTimeoutMs);
  MotorArmRot2_Extend->ConfigPeakOutputForward(1, kTimeoutMs);
  MotorArmRot2_Extend->ConfigPeakOutputReverse(-1, kTimeoutMs);
  MotorArmRot2_Extend->Config_kF(0, constants::climber::kArmExt_F, kTimeoutMs);
  MotorArmRot2_Extend->Config_kP(0, constants::climber::kArmExt_P, kTimeoutMs);
  MotorArmRot2_Extend->Config_kI(0, constants::climber::kArmExt_I, kTimeoutMs);
  MotorArmRot2_Extend->Config_kD(0, constants::climber::kArmExt_D, kTimeoutMs);
  MotorArmRot2_Extend->Config_IntegralZone(0, 400, kTimeoutMs);
  MotorArmRot2_Extend->ConfigAllowableClosedloopError(0,constants::climber::kArmExt_AllowableError,kTimeoutMs); 
  MotorArmRot2_Extend->ConfigMotionCruiseVelocity(constants::climber::kArmExt_MotionCruiseVelocity, kTimeoutMs);
  MotorArmRot2_Extend->ConfigMotionAcceleration(constants::climber::kArmExt_MotionAcceleration, kTimeoutMs);
  MotorArmRot2_Extend->ConfigMotionSCurveStrength(constants::climber::kArmExt_MotionSCurveStrength, kTimeoutMs);
  MotorArmRot2_Extend->ConfigVoltageCompSaturation(constants::climber::kVoltageCompSaturation);
  MotorArmRot2_Extend->EnableVoltageCompensation(true);
  MotorArmRot2_Extend->ConfigForwardSoftLimitThreshold(constants::climber::kArmExt_ExtendLimit);
  MotorArmRot2_Extend->ConfigReverseSoftLimitThreshold(constants::climber::kArmExt_RetractLimit);
  MotorArmRot2_Extend->ConfigForwardSoftLimitEnable(true);
  MotorArmRot2_Extend->ConfigReverseSoftLimitEnable(true);
  
  //Falcon 500, turns CCW
  MotorArmRot1_Rotate = new WPI_TalonFX(constants::climber::kMotorArmRot1_Rotate_ID);//CAN
  MotorArmRot1_Rotate->ConfigFactoryDefault(kTimeoutMs);
  if(!constants::climber::kArmRot_UsePlanetaryGearbox)
  {  //using potentiometer on feeder talon
    MotorArmRot1_Rotate->ConfigRemoteFeedbackFilter(constants::shooter::kMotorFeeder_ID,RemoteSensorSource::RemoteSensorSource_TalonSRX_SelectedSensor,0,kTimeoutMs);
    MotorArmRot1_Rotate->ConfigSelectedFeedbackSensor(FeedbackDevice::RemoteSensor0, 0,kTimeoutMs);
  }
  else
  {  //using falcon integrated encoders
    MotorArmRot1_Rotate->ConfigSelectedFeedbackSensor(FeedbackDevice::IntegratedSensor, 0, kTimeoutMs);
  }
  MotorArmRot1_Rotate->SetNeutralMode(NeutralMode::Brake);
  MotorArmRot1_Rotate->SetInverted(true);
  MotorArmRot1_Rotate->SetSafetyEnabled(false);
  MotorArmRot1_Rotate->ConfigSupplyCurrentLimit(armSCLC); //current limiting
  MotorArmRot1_Rotate->ConfigOpenloopRamp(1.0, kTimeoutMs);
  MotorArmRot1_Rotate->SetStatusFramePeriod(StatusFrameEnhanced::Status_13_Base_PIDF0, 10, 10);
  MotorArmRot1_Rotate->SetStatusFramePeriod(StatusFrameEnhanced::Status_10_MotionMagic, 10, 10);
  MotorArmRot1_Rotate->ConfigNominalOutputForward(0, kTimeoutMs);
  MotorArmRot1_Rotate->ConfigNominalOutputReverse(0, kTimeoutMs);
  MotorArmRot1_Rotate->ConfigPeakOutputForward(1, kTimeoutMs);
  MotorArmRot1_Rotate->ConfigPeakOutputReverse(-1, kTimeoutMs);
  MotorArmRot1_Rotate->Config_kF(0, constants::climber::kArmRot_F, kTimeoutMs);
  MotorArmRot1_Rotate->Config_kP(0, constants::climber::kArmRot_P, kTimeoutMs);
  MotorArmRot1_Rotate->Config_kI(0, constants::climber::kArmRot_I, kTimeoutMs);
  MotorArmRot1_Rotate->Config_kD(0, constants::climber::kArmRot_D, kTimeoutMs);
  MotorArmRot1_Rotate->Config_IntegralZone(0, 400, kTimeoutMs);
  MotorArmRot1_Rotate->ConfigAllowableClosedloopError(0,constants::climber::kArmRot_AllowableError,kTimeoutMs);  
  MotorArmRot1_Rotate->ConfigMotionCruiseVelocity(constants::climber::kArmRot_MotionCruiseVelocity, 10);
  MotorArmRot1_Rotate->ConfigMotionAcceleration(constants::climber::kArmRot_MotionAcceleration, 10);
  MotorArmRot1_Rotate->ConfigMotionSCurveStrength(constants::climber::kArmRot_MotionSCurveStrength);
  MotorArmRot1_Rotate->ConfigVoltageCompSaturation(constants::climber::kVoltageCompSaturation);
  MotorArmRot1_Rotate->EnableVoltageCompensation(true);
  MotorArmRot1_Rotate->ConfigForwardSoftLimitThreshold(constants::climber::kArmRot_ForwardLimit);
  MotorArmRot1_Rotate->ConfigReverseSoftLimitThreshold(constants::climber::kArmRot_ReverseLimit);
  MotorArmRot1_Rotate->ConfigForwardSoftLimitEnable(true);
  MotorArmRot1_Rotate->ConfigReverseSoftLimitEnable(true);

  //Falcon 500,   turns CCW
  MotorArmRot2_Rotate = new WPI_TalonFX(constants::climber::kMotorArmRot2_Rotate_ID);//CAN
  MotorArmRot2_Rotate->ConfigFactoryDefault(kTimeoutMs);
  MotorArmRot2_Rotate->SetInverted(true);
	MotorArmRot2_Rotate->ConfigSupplyCurrentLimit(armSCLC); //current limiting
  MotorArmRot2_Rotate->SetStatusFramePeriod(StatusFrameEnhanced::Status_2_Feedback0, 255, 10);
  MotorArmRot2_Rotate->SetStatusFramePeriod(StatusFrameEnhanced::Status_1_General, 255, 10);
  MotorArmRot2_Rotate->SetNeutralMode(NeutralMode::Brake);
  MotorArmRot2_Rotate->Follow(*MotorArmRot1_Rotate);
  MotorArmRot2_Rotate->SetSafetyEnabled(false);

  //BOSS dashboard on Drive Station computer
  ntBOSS = nt::NetworkTableInstance::GetDefault().GetTable("dashBOSS");

  //set start position for spinner hooks
  MotorArmStat1->SetSelectedSensorPosition(0,0,kTimeoutMs);
  MotorArmStat2->SetSelectedSensorPosition(0,0,kTimeoutMs);
 
  //set the starting position counts for the rotating arm 
  if(!constants::climber::kArmRot_UsePlanetaryGearbox) //using original gearbox with potentiometer for encoder
  {
    ArmRot_Setpoint = MotorArmRot1_Rotate->GetSelectedSensorPosition(0);  //just get current position
  }
  else //using planetary gearbox with falcon integrated encoder - need to zero
  {
    //arm must be set all the way forward at startup for zero to work
    MotorArmRot1_Rotate->SetSelectedSensorPosition(constants::climber::kArmRot_ForwardLimit,0,kTimeoutMs);  
    ArmRot_Setpoint = MotorArmRot1_Rotate->GetSelectedSensorPosition(0);
  }

  //set the starting position counts for the extend
  MotorArmRot1_Extend->SetSelectedSensorPosition(0.0,0,kTimeoutMs);
  MotorArmRot2_Extend->SetSelectedSensorPosition(0.0,0,kTimeoutMs);
  ArmExt_Setpoint = 0;
}

void ClimberClass::Periodic(double joyRotation, bool butExtend, bool butSpin)
{
  static bool spinFlag;
  static bool extFlag;
  static double extSpd;
  double stickY = joyRotation;
  
  //handle rotating arms
  stickY = stickY/3.0;
  if(constants::climber::kArmRot2_UpdateFollower) MotorArmRot2_Rotate->Set(ControlMode::Follower,constants::climber::kMotorArmRot1_Rotate_ID);
  MotorArmRot1_Rotate->Set(ControlMode::PercentOutput,-stickY);
  
  //handle Extenders on rotating arms
  if(butExtend && !extFlag) //set extend speed - oneshot
  {
    extFlag = true;
    extSpd = constants::climber::kArmExt_ExtendSpeed;
  }
  if(!butExtend && extFlag) //set retract speed - oneshot
  {
    extFlag = false;
    extSpd = constants::climber::kArmExt_RetractSpeed;
  }
  if(butExtend) //limit extension
  {
    double ext1Pos = MotorArmRot1_Extend->GetSelectedSensorPosition();
    double ext2Pos = MotorArmRot2_Extend->GetSelectedSensorPosition();
    double extMax = std::max(ext1Pos,ext2Pos);
    if(extMax >= constants::climber::kArmExt_TeleopLimit) extSpd = 0.0;  
  }
  MotorArmRot1_Extend->Set(ControlMode::PercentOutput,extSpd);
  MotorArmRot2_Extend->Set(ControlMode::PercentOutput,extSpd);
  
  //handle one-shot of spinners on static arm
  if(butSpin && !spinFlag)
  {
    spinFlag = true;
    ArmStat_RotateHook();
  }
  if(!butSpin && spinFlag) spinFlag = false;
  MotorArmStat1->Set(ControlMode::MotionMagic,ArmSpin_Setpoint);
  MotorArmStat2->Set(ControlMode::MotionMagic,ArmSpin_Setpoint);

  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    if(constants::kClimberLoggingEnabled)
    {
      //ntBOSS->PutNumber("ArmRotRotate_TGT", MotorArmRot1_Rotate->GetClosedLoopTarget(0));
      ntBOSS->PutNumber("ArmRotRotate_POS",MotorArmRot1_Rotate->GetSelectedSensorPosition());
      //ntBOSS->PutNumber("ArmRotRotate_OUT",MotorArmRot1_Rotate->GetMotorOutputPercent());
      ntBOSS->PutNumber("ArmStat_POS",GetPosArmStat1());
      //ntBOSS->PutNumber("ArmStat_TGT",MotorArmStat1->GetClosedLoopTarget(0));
      //ntBOSS->PutNumber("ArmStat_POS",MotorArmStat1->GetSelectedSensorPosition());
      ntBOSS->PutNumber("ArmStat2_POS",GetPosArmStat2());
      //ntBOSS->PutNumber("ArmStat2_TGT",MotorArmStat2->GetClosedLoopTarget(0));
      //ntBOSS->PutNumber("ArmStat2_POS",MotorArmStat2->GetSelectedSensorPosition());
      //ntBOSS->PutNumber("ArmRotExtend_TGT",MotorArmRot1_Extend->GetClosedLoopTarget(0));
      ntBOSS->PutNumber("ArmRotExtend_POS", MotorArmRot1_Extend->GetSelectedSensorPosition());
      //ntBOSS->PutNumber("ArmRotExtend2_TGT",MotorArmRot2_Extend->GetClosedLoopTarget(0));
      ntBOSS->PutNumber("ArmRotExtend2_POS", MotorArmRot2_Extend->GetSelectedSensorPosition());
    }
  }
}

void ClimberClass::AutoPeriodic()
{
  //handle rotating arms
  ArmRot_Setpoint = clamp2(ArmRot_Setpoint,constants::climber::kArmRot_ReverseLimit,constants::climber::kArmRot_ForwardLimit);
  //MotorArmRot1_Rotate->Set(ControlMode::MotionMagic,ArmRot_Setpoint);
  if(constants::climber::kArmRot2_UpdateFollower) MotorArmRot2_Rotate->Set(ControlMode::Follower,constants::climber::kMotorArmRot1_Rotate_ID);
  double scalar = (100.0 - (constants::climber::kArmRot_ForwardLimit - ArmRot_Setpoint))/100.0;  //multiplier = 1 @ 343 and 0 @ 242
  MotorArmRot1_Rotate->Set(ControlMode::MotionMagic,ArmRot_Setpoint,DemandType::DemandType_ArbitraryFeedForward,constants::climber::kArmRot_AFF * scalar);
  
  ArmExt_Setpoint = clamp2(ArmExt_Setpoint,constants::climber::kArmExt_RetractLimit,constants::climber::kArmExt_ExtendLimit);
  MotorArmRot1_Extend->Set(ControlMode::MotionMagic,ArmExt_Setpoint);
  MotorArmRot2_Extend->Set(ControlMode::MotionMagic,ArmExt_Setpoint);

  MotorArmStat1->Set(ControlMode::MotionMagic,ArmSpin_Setpoint);
  MotorArmStat2->Set(ControlMode::MotionMagic,ArmSpin_Setpoint);

  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    if(constants::kClimberLoggingEnabled)
    {
      ntBOSS->PutNumber("ArmRotRotate_TGT", MotorArmRot1_Rotate->GetClosedLoopTarget(0));
      ntBOSS->PutNumber("ArmRotRotate_POS",MotorArmRot1_Rotate->GetSelectedSensorPosition());
      ntBOSS->PutNumber("ArmStat_POS",GetPosArmStat1());
      ntBOSS->PutNumber("ArmStat_TGT",MotorArmStat1->GetClosedLoopTarget(0));
      //ntBOSS->PutNumber("ArmStat_POS",MotorArmStat1->GetSelectedSensorPosition());
      ntBOSS->PutNumber("ArmStat2_POS",GetPosArmStat2());
      ntBOSS->PutNumber("ArmStat2_TGT",MotorArmStat2->GetClosedLoopTarget(0));
      //ntBOSS->PutNumber("ArmStat2_POS",MotorArmStat2->GetSelectedSensorPosition());
      ntBOSS->PutNumber("ArmRotExtend_TGT",MotorArmRot1_Extend->GetClosedLoopTarget(0));
      ntBOSS->PutNumber("ArmRotExtend_POS", MotorArmRot1_Extend->GetSelectedSensorPosition());
      ntBOSS->PutNumber("ArmRotExtend2_TGT",MotorArmRot2_Extend->GetClosedLoopTarget(0));
      ntBOSS->PutNumber("ArmRotExtend2_POS", MotorArmRot2_Extend->GetSelectedSensorPosition());
    }
  }
}

bool ClimberClass::ExtendersAreAtPosition()
{
  static int counter; //each count is 20ms, so 50 = 1 sec
  bool onTarget = false;
  double min = MotorArmRot1_Extend->GetClosedLoopTarget() - constants::climber::kArmExt_PositionDB;
  double max = MotorArmRot1_Extend->GetClosedLoopTarget() + constants::climber::kArmExt_PositionDB;
  
  double pos1 = MotorArmRot1_Extend->GetSelectedSensorPosition(0);
  double pos2 = MotorArmRot2_Extend->GetSelectedSensorPosition(0);
  if((pos1 >= min) && (pos1 <= max) && (pos2 >= min) && (pos2 <= max))
  {
    counter++;
    if(counter >= constants::climber::kArmExt_TargetDelay) 
    {
      counter = 0;
      onTarget = true;
    }
  }
  return onTarget;
}

bool ClimberClass::RotatingArmsAtPosition()
{
  static int counter; //each count is 20ms, so 50 = 1 sec
  bool onTarget = false;
  double min = MotorArmRot1_Rotate->GetClosedLoopTarget() - constants::climber::kArmRot_PositionDB;
  double max = MotorArmRot1_Rotate->GetClosedLoopTarget() + constants::climber::kArmRot_PositionDB;
  
  double pos = MotorArmRot1_Rotate->GetSelectedSensorPosition(0);
  if((pos >= min) && (pos <= max))
  {
    counter++;
    if(counter >= constants::climber::kArmRot_TargetDelay) 
    {
      counter = 0;
      onTarget = true;
    }
  }
  return onTarget;
}

bool ClimberClass::SpinnersAreHooked()  //Are spinner hooks within 340-20 deg?  true if yes
{
  static int counter; //each count is 20ms, so 50 = 1 sec
  bool onTarget = false;
  
  double counts1 = std::fmod(MotorArmStat1->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution);
  double counts2 = std::fmod(MotorArmStat2->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution);
  bool hook1 = (counts1 > 12882) || (counts1 < 1000);
  bool hook2 = (counts2 > 12882) || (counts2 < 1000);
  if(hook1 && hook2)
  {
    counter++;
    if(counter >= constants::climber::kSpin_TargetDelay) 
    {
      counter = 0;
      onTarget = true;
    }
  }
  else counter = 0;
  return onTarget;
}

bool ClimberClass::SpinnersAreNotHooked()  //Are spinner hooks within 160-200 deg?  true if yes
{
  static int counter; //each count is 20ms, so 50 = 1 sec
  bool onTarget = false;
  
  double counts1 = std::fmod(MotorArmStat1->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution);
  double counts2 = std::fmod(MotorArmStat2->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution);
  bool hook1 = (counts1 > 6063) && (counts1 < 7578);
  bool hook2 = (counts2 > 6063) && (counts2 < 7578);
  if(hook1 && hook2)
  {
    counter++;
    if(counter >= constants::climber::kSpin_TargetDelay) 
    {
      counter = 0;
      onTarget = true;
    }
  }
  else counter = 0;
  return onTarget;
}

void ClimberClass::TestArmRotatePosition()
{
  ArmRot_Setpoint = clamp2(ArmRot_Setpoint,constants::climber::kArmRot_ReverseLimit,constants::climber::kArmRot_ForwardLimit);
  //MotorArmRot1_Rotate->Set(ControlMode::MotionMagic,ArmRot_Setpoint);
  if(constants::climber::kArmRot2_UpdateFollower) MotorArmRot2_Rotate->Set(ControlMode::Follower,constants::climber::kMotorArmRot1_Rotate_ID);
  double scalar = (100.0 - (constants::climber::kArmRot_ForwardLimit - ArmRot_Setpoint))/100.0;  //multiplier = 1 @ 343 and 0 @ 242
  MotorArmRot1_Rotate->Set(ControlMode::MotionMagic,ArmRot_Setpoint,DemandType::DemandType_ArbitraryFeedForward,constants::climber::kArmRot_AFF * scalar);
  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    ntBOSS->PutNumber("ArmRotRotate_TGT", ArmRot_Setpoint);
    ntBOSS->PutNumber("ArmRotRotate_POS", MotorArmRot1_Rotate->GetSelectedSensorPosition(0));
    //ntBOSS->PutNumber("ArmRotRotate_OUT", MotorArmRot1_Rotate->GetMotorOutputPercent() * 100.0);
  }
}

void ClimberClass::TestArmSpinPosition(bool butSpin)
{
  static bool spinFlag;
  //handle one-shot of spinners on static arm
  if(butSpin && !spinFlag)
  {
    spinFlag = true;
    ArmStat_RotateHook();
  }
  if(!butSpin && spinFlag) spinFlag = false;
  MotorArmStat1->Set(ControlMode::MotionMagic,ArmSpin_Setpoint);
  MotorArmStat2->Set(ControlMode::MotionMagic,ArmSpin_Setpoint);
  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 15)
  {
    counter = 0;
    ntBOSS->PutNumber("ArmStat_POS",GetPosArmStat1());
    ntBOSS->PutNumber("ArmStat_TGT",MotorArmStat1->GetClosedLoopTarget(0));
    ntBOSS->PutNumber("ArmStat2_POS",GetPosArmStat2());
    ntBOSS->PutNumber("ArmStat2_TGT",MotorArmStat2->GetClosedLoopTarget(0));
  }
}

void ClimberClass::TestArmExtendPosition()
{
  ArmExt_Setpoint = clamp2(ArmExt_Setpoint,constants::climber::kArmExt_RetractLimit,constants::climber::kArmExt_ExtendLimit);
  MotorArmRot1_Extend->Set(ControlMode::MotionMagic,ArmExt_Setpoint);
  MotorArmRot2_Extend->Set(ControlMode::MotionMagic,ArmExt_Setpoint);
  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 11)
  {
    counter = 0;
    ntBOSS->PutNumber("ArmRotExtend_TGT",MotorArmRot1_Extend->GetClosedLoopTarget(0));
    ntBOSS->PutNumber("ArmRotExtend_POS", MotorArmRot1_Extend->GetSelectedSensorPosition());
    ntBOSS->PutNumber("ArmRotExtend2_TGT",MotorArmRot2_Extend->GetClosedLoopTarget(0));
    ntBOSS->PutNumber("ArmRotExtend2_POS", MotorArmRot2_Extend->GetSelectedSensorPosition());
  }
}

//synchronizes the armrot_setpoint value to current arm position
void ClimberClass::SyncRotateSetpoint()
{
  ArmRot_Setpoint = MotorArmRot1_Rotate->GetSelectedSensorPosition(0);
  ntBOSS->PutNumber("ArmRotRotate_TGT", ArmRot_Setpoint);
}

//synchronizes the armext_setpoint value to current extend position
void ClimberClass::SyncExtendSetpoint()
{
  ArmRot_Setpoint = MotorArmRot1_Extend->GetSelectedSensorPosition(0);
  ntBOSS->PutNumber("ArmRotExtend_TGT", ArmExt_Setpoint);
}

void ClimberClass::ArmStat_RotateHook()
{
  //get current counts and add counts - half of final CPR of spinnerHook (13653)
  ArmSpin_Setpoint = ArmSpin_Setpoint + constants::climber::kArmStat_RotateCounts;
}

void ClimberClass::MoveSpinnersIN()
{
  //if(!SpinnersAreIN())
  //{
    ArmSpin_Setpoint = ArmSpin_Setpoint + constants::climber::kArmStat_RotateCounts;
  //}
}

void ClimberClass::MoveSpinnersOUT()
{
  //if(SpinnersAreIN() && SpinnersAreFreeToMove())
  //{
    ArmSpin_Setpoint = ArmSpin_Setpoint + constants::climber::kArmStat_RotateCounts;
  //}
}

void ClimberClass::TestSpinners(double output)
{
  MotorArmStat1->Set(ControlMode::PercentOutput,output);
  MotorArmStat2->Set(ControlMode::PercentOutput,output);
  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    ntBOSS->PutNumber("ArmStat_POS",GetPosArmStat1());
    //ntBOSS->PutNumber("ArmStat_POS",MotorArmStat1->GetSelectedSensorPosition(0));
    ntBOSS->PutNumber("ArmStat2_POS",GetPosArmStat2());
    //ntBOSS->PutNumber("ArmStat2_POS",MotorArmStat2->GetSelectedSensorPosition(0));
  }
}

void ClimberClass::TestSpinner1(double output)
{
  MotorArmStat1->Set(ControlMode::PercentOutput,output);
  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    double pos = (std::fmod(MotorArmStat1->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution) * constants::climber::kSpinUnitsToDegrees);
    //ntBOSS->PutNumber("ArmStat_DEG",pos);
    ntBOSS->PutNumber("ArmStat_POS",pos);
  }
  //double counts1 = std::fmod(MotorArmStat1->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution);
  //ntBOSS->PutNumber("spin_Hooked_1", counts1);
}

void ClimberClass::TestSpinner2(double output)
{
  MotorArmStat2->Set(ControlMode::PercentOutput,output);
  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    double pos = (std::fmod(MotorArmStat2->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution) * constants::climber::kSpinUnitsToDegrees);
    ntBOSS->PutNumber("ArmStat2_POS",pos);
    //ntBOSS->PutNumber("ArmStat2_POS",MotorArmStat2->GetSelectedSensorPosition(0));
  }
}

void ClimberClass::TestArmExtend(double output)
{
  MotorArmRot1_Extend->Set(ControlMode::PercentOutput,output);
  MotorArmRot2_Extend->Set(ControlMode::PercentOutput,output);
  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    ntBOSS->PutNumber("ArmRotExtend_POS", MotorArmRot1_Extend->GetSelectedSensorPosition(0));
    ntBOSS->PutNumber("ArmRotExtend2_POS", MotorArmRot2_Extend->GetSelectedSensorPosition(0));
  }
}

void ClimberClass::TestArmExtend1(double output)
{
  MotorArmRot1_Extend->Set(ControlMode::PercentOutput,output);
  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    ntBOSS->PutNumber("ArmRotExtend_POS", MotorArmRot1_Extend->GetSelectedSensorPosition(0));
  }
}

void ClimberClass::TestArmExtend2(double output)
{
  MotorArmRot2_Extend->Set(ControlMode::PercentOutput,output);
  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    ntBOSS->PutNumber("ArmRotExtend2_POS", MotorArmRot2_Extend->GetSelectedSensorPosition(0));
  }
}

void ClimberClass::TestArmRotate(double output)
{
  if(constants::climber::kArmRot2_UpdateFollower) MotorArmRot2_Rotate->Set(ControlMode::Follower,constants::climber::kMotorArmRot1_Rotate_ID);
  MotorArmRot1_Rotate->Set(ControlMode::PercentOutput,output);
  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    //ntBOSS->PutNumber("ArmRotRotate_TGT", output);
    ntBOSS->PutNumber("ArmRotRotate_POS", MotorArmRot1_Rotate->GetSelectedSensorPosition(0));
  }
}

void ClimberClass::Disable()
{
  MotorArmStat1->Set(ControlMode::PercentOutput, 0.0);
  MotorArmStat2->Set(ControlMode::PercentOutput, 0.0);
  MotorArmRot1_Extend->Set(ControlMode::PercentOutput, 0.0);
  MotorArmRot2_Extend->Set(ControlMode::PercentOutput, 0.0);
  if(constants::climber::kArmRot2_UpdateFollower) MotorArmRot2_Rotate->Set(ControlMode::Follower,constants::climber::kMotorArmRot1_Rotate_ID);
  MotorArmRot1_Rotate->Set(ControlMode::PercentOutput, 0.0);
}

void ClimberClass::EnableSoftReverseLimits(bool enable)
{
  MotorArmRot1_Extend->ConfigReverseSoftLimitEnable(enable);
  MotorArmRot2_Extend->ConfigReverseSoftLimitEnable(enable);
  //if using planetary gearbox, we zero on forward limit
  if(constants::climber::kArmRot_UsePlanetaryGearbox) MotorArmRot1_Rotate->ConfigForwardSoftLimitEnable(enable);
  
}

double ClimberClass::GetPosArmStat1()  //returns counts
{
  //don't care about rotations, so use modulus to get count remainder
  //return (std::fmod(MotorArmStat1->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution) * constants::climber::kSpinUnitsToDegrees);
  return (std::fmod(MotorArmStat1->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution));
}

double ClimberClass::GetPosArmStat2()  //returns counts
{
  //don't care about rotations, so use modulus to get count remainder
  //return (std::fmod(MotorArmStat2->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution) * constants::climber::kSpinUnitsToDegrees);
  return (std::fmod(MotorArmStat2->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution));
}

double ClimberClass::GetPosArmRot1Extend()  //returns counts
{
  return (MotorArmRot1_Extend->GetSelectedSensorPosition(0));
}

double ClimberClass::GetPosArmRot2Extend()  //returns counts
{
  return (MotorArmRot2_Extend->GetSelectedSensorPosition(0));
}

double ClimberClass::GetPosArmRotRotate()  //returns counts
{
  return (MotorArmRot1_Rotate->GetSelectedSensorPosition(0));
}

//interlock spinners with position of rotating arm
bool ClimberClass::SpinnersAreFreeToMove()
{
  double pos = MotorArmRot1_Rotate->GetSelectedSensorPosition(0);
  if(pos >= constants::climber::kArmsAreClear) return true;
  else return false;
  //return true;
}

//start with spinners pointed in  
bool ClimberClass::SpinnersAreIN()  //Are spinner hooks pointed toward intake?  true if yes
{
  double counts1 = std::fmod(MotorArmStat1->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution);
  double counts2 = std::fmod(MotorArmStat2->GetSelectedSensorPosition(0),constants::climber::kSpinCountsPerRevolution);
  bool hook1 = (counts1 > 12882) || (counts1 < 1000);
  bool hook2 = (counts2 > 12882) || (counts2 < 1000);
  if(hook1 && hook2) return true;
  else return false;
}



void ClimberClass::CheckFaults()
{
  SRX_CheckFaults(MotorArmStat1,"SPINNER 1",8);
  SRX_CheckFaults(MotorArmStat2,"SPINNER 2",9);
  SRX_CheckFaults(MotorArmRot1_Extend,"EXTEND 1",10);
  SRX_CheckFaults(MotorArmRot2_Extend,"EXTEND 2",11);
  FX_CheckFaults(MotorArmRot1_Rotate,"ROTATE 1",12);
  FX_CheckFaults(MotorArmRot2_Rotate,"ROTATE 2",13);
  ntBOSS->PutNumber("ClimberFault", ClimberFault);
}

void ClimberClass::ClearStickyFaults()
{
  MotorArmStat1->ClearStickyFaults();
  MotorArmStat2->ClearStickyFaults();
  MotorArmRot1_Extend->ClearStickyFaults();
  MotorArmRot2_Extend->ClearStickyFaults();
  MotorArmRot1_Rotate->ClearStickyFaults();
  MotorArmRot2_Rotate->ClearStickyFaults();
}

void ClimberClass::FX_CheckFaults(WPI_TalonFX *Motor,std::string name, short bit)
{
  Faults f;
  StickyFaults sf;
  
  ClimberFault = clearBit(ClimberFault,bit);
  Motor->GetFaults(f);
  Motor->GetStickyFaults(sf);
  if(f.ResetDuringEn || f.SensorOutOfPhase || f.UnderVoltage)
  {
    ClimberFault = setBit(ClimberFault,bit);
    if(f.ResetDuringEn) printf("%s: %s\n",name.c_str(),"RESET DURING ENABLE");
    if(f.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"OUT OF PHASE");
    if(f.UnderVoltage) printf("%s: %s\n",name.c_str(),"UNDER VOLTAGE");
  }
  if(sf.ResetDuringEn || sf.SensorOutOfPhase || sf.UnderVoltage)
  {
    ClimberFault = setBit(ClimberFault,bit);  
    if(sf.ResetDuringEn) printf("%s: %s\n",name.c_str(),"STICKY RESET DURING ENABLE");
    if(sf.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"STICKY OUT OF PHASE");
    if(sf.UnderVoltage) printf("%s: %s\n",name.c_str(),"STICKY UNDER VOLTAGE");
  }
}

void ClimberClass::SRX_CheckFaults(WPI_TalonSRX *Motor,std::string name,short bit)
{
  Faults f;
  StickyFaults sf;
  
  ClimberFault = clearBit(ClimberFault,bit);
  Motor->GetFaults(f);
  Motor->GetStickyFaults(sf);
  if(f.ResetDuringEn || f.SensorOutOfPhase || f.UnderVoltage)
  {
    ClimberFault = setBit(ClimberFault,bit);
    if(f.ResetDuringEn) printf("%s: %s\n",name.c_str(),"RESET DURING ENABLE");
    if(f.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"OUT OF PHASE");
    if(f.UnderVoltage) printf("%s: %s\n",name.c_str(),"UNDER VOLTAGE");
  }
  if(sf.ResetDuringEn || sf.SensorOutOfPhase || sf.UnderVoltage)
  {
    ClimberFault = setBit(ClimberFault,bit);  
    if(sf.ResetDuringEn) printf("%s: %s\n",name.c_str(),"STICKY RESET DURING ENABLE");
    if(sf.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"STICKY OUT OF PHASE");
    if(sf.UnderVoltage) printf("%s: %s\n",name.c_str(),"STICKY UNDER VOLTAGE");
  }
}

void ClimberClass::GetMaxAmps(bool SendToDash)
{
  double tmp;

  if(constants::kClimberLoggingEnabled)
  {
    tmp = MotorArmStat1->GetOutputCurrent();  
    if(tmp > Spinner1MaxAmps) Spinner1MaxAmps = tmp;
    tmp = MotorArmStat2->GetOutputCurrent();
    if(tmp > Spinner2MaxAmps) Spinner2MaxAmps = tmp;
    tmp = MotorArmRot1_Extend->GetOutputCurrent();
    if(tmp > Extend1MaxAmps) Extend1MaxAmps = tmp;
    tmp = MotorArmRot2_Extend->GetOutputCurrent();
    if(tmp > Extend2MaxAmps) Extend2MaxAmps = tmp;
    tmp = MotorArmRot1_Rotate->GetOutputCurrent();
    if(tmp > Rotate1MaxAmps) Rotate1MaxAmps = tmp;
    tmp = MotorArmRot2_Rotate->GetOutputCurrent();
    if(tmp > Rotate2MaxAmps) Rotate2MaxAmps = tmp;
    if(SendToDash)
    {
      ntBOSS->PutNumber("Spinner1_AMP",Spinner1MaxAmps);
      ntBOSS->PutNumber("Spinner2_AMP",Spinner2MaxAmps);
      ntBOSS->PutNumber("Extend1_AMP",Extend1MaxAmps);
      ntBOSS->PutNumber("Extend2_AMP",Extend2MaxAmps);
      ntBOSS->PutNumber("Rotate1_AMP",Rotate1MaxAmps);
      ntBOSS->PutNumber("Rotate2_AMP",Rotate2MaxAmps);
    }
  }
}

void ClimberClass::ResetMaxAmps()
{
  Spinner1MaxAmps = 0;
  Spinner2MaxAmps = 0;
  Extend1MaxAmps = 0;
  Extend2MaxAmps = 0;
  Rotate1MaxAmps = 0;
  Rotate2MaxAmps = 0;
}

void ClimberClass::ZeroSpin()
{
  //set start position for spinner hooks
  MotorArmStat1->SetSelectedSensorPosition(0,0,kTimeoutMs);
  MotorArmStat2->SetSelectedSensorPosition(0,0,kTimeoutMs);
}

void ClimberClass::ZeroExtend()
{
  //set the starting position counts for the extend
  MotorArmRot1_Extend->SetSelectedSensorPosition(0.0,0,kTimeoutMs);
  MotorArmRot2_Extend->SetSelectedSensorPosition(0.0,0,kTimeoutMs);
  ArmExt_Setpoint = 0;
}

void ClimberClass::ZeroRotate()
{
  if(!constants::climber::kArmRot_UsePlanetaryGearbox) //using original gearbox with potentiometer for encoder
  {
    ArmRot_Setpoint = MotorArmRot1_Rotate->GetSelectedSensorPosition(0);  //just get current position
  }
  else //using planetary gearbox with falcon integrated encoder - need to zero
  {
    //arm must be set all the way forward at startup for zero to work
    MotorArmRot1_Rotate->SetSelectedSensorPosition(constants::climber::kArmRot_ForwardLimit,0,kTimeoutMs);  
    ArmRot_Setpoint = MotorArmRot1_Rotate->GetSelectedSensorPosition(0);
  }
}

void ClimberClass::ResetRotateFollow()
{
  MotorArmRot2_Rotate->Follow(*MotorArmRot1_Rotate);
}
