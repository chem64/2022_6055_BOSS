#include "Intake.h"
using namespace frc;

enum Constants {kSlotIdx = 0, kPIDLoopIdx = 0, kTimeoutMs = 50};

void IntakeClass::Init()
{
  //??
  MotorIntakeWheels = new WPI_TalonSRX(constants::intake::kMotorIntakeWheels_ID);//CAN
  MotorIntakeWheels->ConfigFactoryDefault(kTimeoutMs);
  MotorIntakeWheels->ConfigOpenloopRamp(constants::intake::kOpenLoopRamp, kTimeoutMs);
  MotorIntakeWheels->SetNeutralMode(NeutralMode::Brake);
  MotorIntakeWheels->SetInverted(true);
  MotorIntakeWheels->SetSafetyEnabled(false);
  MotorIntakeWheels->ConfigPeakCurrentLimit(constants::intake::kPeakCurrentLimit, kTimeoutMs);
  MotorIntakeWheels->ConfigPeakCurrentDuration(constants::intake::kPeakCurrentDuration, kTimeoutMs);
  MotorIntakeWheels->ConfigContinuousCurrentLimit(constants::intake::kContinuousCurrentLimit, kTimeoutMs);
  MotorIntakeWheels->EnableCurrentLimit(true);
  MotorIntakeWheels->SetStatusFramePeriod(StatusFrameEnhanced::Status_2_Feedback0, 255, 10);
  MotorIntakeWheels->SetStatusFramePeriod(StatusFrameEnhanced::Status_1_General, 255, 10);
  MotorIntakeWheels->ConfigVoltageCompSaturation(constants::intake::kVoltageCompSaturation);
  MotorIntakeWheels->EnableVoltageCompensation(true);

    // Bag motors 18/42 reduction after encoder - output shaft turns CCW
  MotorIntakePosition = new WPI_TalonSRX(constants::intake::kMotorIntakePosition_ID);//CAN
  MotorIntakePosition->ConfigFactoryDefault(kTimeoutMs);
  MotorIntakePosition->ConfigSelectedFeedbackSensor(FeedbackDevice::CTRE_MagEncoder_Relative, 0,kTimeoutMs);
  MotorIntakePosition->SetNeutralMode(NeutralMode::Brake);
  MotorIntakePosition->SetSensorPhase(false);
  MotorIntakePosition->SetInverted(true);
  MotorIntakePosition->SetSafetyEnabled(false);
  MotorIntakePosition->ConfigPeakCurrentLimit(constants::intake::kPeakCurrentLimit, kTimeoutMs);
  MotorIntakePosition->ConfigPeakCurrentDuration(constants::intake::kPeakCurrentDuration, kTimeoutMs);
  MotorIntakePosition->ConfigContinuousCurrentLimit(constants::intake::kContinuousCurrentLimit, kTimeoutMs);
  MotorIntakePosition->EnableCurrentLimit(true);
  MotorIntakePosition->SetStatusFramePeriod(StatusFrameEnhanced::Status_13_Base_PIDF0, 10, 10);
  MotorIntakePosition->SetStatusFramePeriod(StatusFrameEnhanced::Status_10_MotionMagic, 10, 10);
  MotorIntakePosition->ConfigNominalOutputForward(0, kTimeoutMs);
  MotorIntakePosition->ConfigNominalOutputReverse(0, kTimeoutMs);
  MotorIntakePosition->ConfigPeakOutputForward(1, kTimeoutMs);
  MotorIntakePosition->ConfigPeakOutputReverse(-1, kTimeoutMs);
  MotorIntakePosition->Config_kF(0, constants::intake::kF, kTimeoutMs);
  MotorIntakePosition->Config_kP(0, constants::intake::kP, kTimeoutMs);
  MotorIntakePosition->Config_kI(0, constants::intake::kI, kTimeoutMs);
  MotorIntakePosition->Config_kD(0, constants::intake::kD, kTimeoutMs);
  MotorIntakePosition->Config_IntegralZone(0, 400, kTimeoutMs);
  MotorIntakePosition->ConfigMotionCruiseVelocity(constants::intake::kMotionCruiseVelocity, 10);
  MotorIntakePosition->ConfigMotionAcceleration(constants::intake::kMotionAcceleration, 10);
  MotorIntakePosition->ConfigMotionSCurveStrength(constants::intake::kMotionSCurveStrength);
  MotorIntakePosition->ConfigVoltageCompSaturation(constants::intake::kVoltageCompSaturation);
  MotorIntakePosition->EnableVoltageCompensation(true);
  MotorIntakePosition->ConfigForwardSoftLimitThreshold(constants::intake::kPositionExtendLimit);
  MotorIntakePosition->ConfigReverseSoftLimitThreshold(constants::intake::kPositionRetractLimit);
  MotorIntakePosition->ConfigForwardSoftLimitEnable(true);
  MotorIntakePosition->ConfigReverseSoftLimitEnable(true);
  MotorIntakePosition->ConfigAllowableClosedloopError(0,10,kTimeoutMs);  

  MotorIntakePosition->SetSelectedSensorPosition(0,0,kTimeoutMs);
   //BOSS dashboard on Drive Station computer
  ntBOSS = nt::NetworkTableInstance::GetDefault().GetTable("dashBOSS");
}

void IntakeClass::Periodic(bool butIntake, bool wheelsOnly)
{
  if(butIntake && Pos_Target != constants::intake::kPos_Extend) Pos_Target = constants::intake::kPos_Extend;   
  if(!butIntake && Pos_Target != constants::intake::kPos_Retract) Pos_Target = constants::intake::kPos_Retract;   
  MotorIntakePosition->Set(ControlMode::MotionMagic, Pos_Target);

  //turn on/off intake wheel rotation
  if(butIntake || wheelsOnly) MotorIntakeWheels->Set(ControlMode::PercentOutput,Whl_Speed);
  else MotorIntakeWheels->Set(ControlMode::PercentOutput,0.0);

  //update dashboard every 250 msecs
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    if(constants::kIntakeLoggingEnabled)
    {
      ntBOSS->PutNumber("Intake_TGT",MotorIntakePosition->GetClosedLoopTarget(0));
      ntBOSS->PutNumber("Intake_POS", MotorIntakePosition->GetSelectedSensorPosition(0));
    }
  }
}

void IntakeClass::TestIntakePosition(double output)
{
  MotorIntakePosition->Set(ControlMode::PercentOutput,output);
  if(constants::kIntakeLoggingEnabled) 
  {
    //update dashboard every 250 msecs
    static int counter = 0;
    counter++;
    if(counter >= 13)
    {
      counter = 0;
      ntBOSS->PutNumber("Intake_POS", MotorIntakePosition->GetSelectedSensorPosition(0));
    }
  }
}

void IntakeClass::TestIntakeWheels(double output)
{
  MotorIntakeWheels->Set(ControlMode::PercentOutput,output);
  if(constants::kIntakeLoggingEnabled) 
  {
    //update dashboard every 250 msecs
    static int counter = 0;
    counter++;
    if(counter >= 13)
    {
      counter = 0;
      ntBOSS->PutNumber("Intake_SPD", MotorIntakeWheels->GetMotorOutputPercent());    
    }
  }
}

void IntakeClass::Disable()
{
  MotorIntakePosition->Set(ControlMode::PercentOutput, 0.0);
  MotorIntakeWheels->Set(ControlMode::PercentOutput,0.0);
}

void IntakeClass::EnableSoftReverseLimits(bool enable)
{
  MotorIntakePosition->ConfigReverseSoftLimitEnable(enable);
}

void IntakeClass::ZeroPosition()
{
  //set ticks equal to zero
  MotorIntakePosition->SetSelectedSensorPosition(0,0,50);
}

void IntakeClass::CheckFaults()
{
  SRX_CheckFaults(MotorIntakeWheels,"INTAKE WHEELS",4);
  SRX_CheckFaults(MotorIntakePosition,"INTAKE POSITION",5);
  ntBOSS->PutNumber("IntakeFault", IntakeFault);
}

void IntakeClass::ClearStickyFaults()
{
  MotorIntakeWheels->ClearStickyFaults();
  MotorIntakePosition->ClearStickyFaults();
}

void IntakeClass::FX_CheckFaults(WPI_TalonFX *Motor,std::string name,short bit)
{
  Faults f;
  StickyFaults sf;
  
  IntakeFault = clearBit(IntakeFault,bit);
  Motor->GetFaults(f);
  Motor->GetStickyFaults(sf);
  if(f.ResetDuringEn || f.SensorOutOfPhase || f.UnderVoltage)
  {
    IntakeFault = setBit(IntakeFault,bit);
    if(f.ResetDuringEn) printf("%s: %s\n",name.c_str(),"RESET DURING ENABLE");
    if(f.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"OUT OF PHASE");
    if(f.UnderVoltage) printf("%s: %s\n",name.c_str(),"UNDER VOLTAGE");
  }
  if(sf.ResetDuringEn || sf.SensorOutOfPhase || sf.UnderVoltage)
  {
    IntakeFault = setBit(IntakeFault,bit);  
    if(sf.ResetDuringEn) printf("%s: %s\n",name.c_str(),"STICKY RESET DURING ENABLE");
    if(sf.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"STICKY OUT OF PHASE");
    if(sf.UnderVoltage) printf("%s: %s\n",name.c_str(),"STICKY UNDER VOLTAGE");
  }
}

void IntakeClass::SRX_CheckFaults(WPI_TalonSRX *Motor,std::string name,short bit)
{
  Faults f;
  StickyFaults sf;
  
  IntakeFault = clearBit(IntakeFault,bit);
  Motor->GetFaults(f);
  Motor->GetStickyFaults(sf);
  if(f.ResetDuringEn || f.SensorOutOfPhase || f.UnderVoltage)
  {
    IntakeFault = setBit(IntakeFault,bit);
    if(f.ResetDuringEn) printf("%s: %s\n",name.c_str(),"RESET DURING ENABLE");
    if(f.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"OUT OF PHASE");
    if(f.UnderVoltage) printf("%s: %s\n",name.c_str(),"UNDER VOLTAGE");
  }
  if(sf.ResetDuringEn || sf.SensorOutOfPhase || sf.UnderVoltage)
  {
    IntakeFault = setBit(IntakeFault,bit);  
    if(sf.ResetDuringEn) printf("%s: %s\n",name.c_str(),"STICKY RESET DURING ENABLE");
    if(sf.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"STICKY OUT OF PHASE");
    if(sf.UnderVoltage) printf("%s: %s\n",name.c_str(),"STICKY UNDER VOLTAGE");
  }
}

void IntakeClass::GetMaxAmps(bool SendToDash)
{
  double tmp;

  if(constants::kIntakeLoggingEnabled)
  {
    tmp = MotorIntakeWheels->GetOutputCurrent();  
    if(tmp > IntakeWheelsMaxAmps) IntakeWheelsMaxAmps = tmp;
    tmp = MotorIntakePosition->GetOutputCurrent();
    if(tmp > IntakePositionMaxAmps) IntakePositionMaxAmps = tmp;
    if(SendToDash)
    {
      ntBOSS->PutNumber("IntakeWheels_AMP",IntakeWheelsMaxAmps);
      ntBOSS->PutNumber("IntakePosition_AMP",IntakePositionMaxAmps);
    }
  }
}

void IntakeClass::ResetMaxAmps()
{
  IntakeWheelsMaxAmps = 0;
  IntakePositionMaxAmps = 0;
}