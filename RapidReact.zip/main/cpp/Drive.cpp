#include "Drive.h"
#include "Utility.h"
using namespace frc;

enum Constants {kSlotIdx = 0, kPIDLoopIdx = 0, kTimeoutMs = 50};

void DriveClass::Init()
{
  SupplyCurrentLimitConfiguration driveSCLC = SupplyCurrentLimitConfiguration{true,constants::drive::kSupplyCurrentLimit,constants::drive::kPeakCurrentLimit,constants::drive::kPeakCurrentDuration};
  StatorCurrentLimitConfiguration statorSCLC = StatorCurrentLimitConfiguration{true,constants::drive::kStatorCurrentLimit,constants::drive::kStatorPeakCurrentLimit,constants::drive::kStatorPeakCurrentDuration};
  
  //Falcon500, 7.71:1 ratio, 4" wheels
  MotorLF = new WPI_TalonFX(constants::drive::kMotorLF_ID); //CAN
  MotorLF->ConfigFactoryDefault(kTimeoutMs);
  MotorLF->ConfigSelectedFeedbackSensor(FeedbackDevice::IntegratedSensor, 0, kTimeoutMs);
  MotorLF->SetInverted(false);
  MotorLF->ConfigNeutralDeadband(0.04, kTimeoutMs);
  MotorLF->SetNeutralMode(NeutralMode::Brake);
  MotorLF->ConfigNominalOutputForward(0, kTimeoutMs);
  MotorLF->ConfigNominalOutputReverse(0, kTimeoutMs);
  MotorLF->ConfigPeakOutputForward(1, kTimeoutMs);
  MotorLF->ConfigPeakOutputReverse(-1, kTimeoutMs);
  MotorLF->Config_kF(0, constants::drive::kF, kTimeoutMs);
  MotorLF->Config_kP(0, constants::drive::kP, kTimeoutMs);
  MotorLF->Config_kI(0, constants::drive::kI, kTimeoutMs);
  MotorLF->Config_kD(0, constants::drive::kD, kTimeoutMs);
  MotorLF->ConfigOpenloopRamp(constants::drive::kOpenLoopRamp,kTimeoutMs); 
  MotorLF->Config_IntegralZone(0, 400, kTimeoutMs);
  MotorLF->ConfigClosedLoopPeakOutput(0,1.0,kTimeoutMs);
  MotorLF->ConfigSupplyCurrentLimit(driveSCLC);//CURRENT_LIMITING
  MotorLF->ConfigStatorCurrentLimit(statorSCLC);//CURRENT_LIMITING
  MotorLF->SetStatusFramePeriod(StatusFrameEnhanced::Status_13_Base_PIDF0, 10, 10);
  MotorLF->SetStatusFramePeriod(StatusFrameEnhanced::Status_10_MotionMagic, 10, 10);
  MotorLF->ConfigVoltageCompSaturation(constants::drive::kVoltageCompSaturation);
  MotorLF->EnableVoltageCompensation(true);
  MotorLF->SetSafetyEnabled(false);
  
  //Falcon500, 7.71:1 ratio, 4" wheels
  MotorLR = new WPI_TalonFX(constants::drive::kMotorLR_ID); //CAN
  MotorLR->ConfigFactoryDefault(kTimeoutMs);
  MotorLR->SetInverted(false);
  MotorLR->ConfigSupplyCurrentLimit(driveSCLC);//CURRENT_LIMITING
  MotorLR->ConfigStatorCurrentLimit(statorSCLC);//CURRENT_LIMITING
  MotorLR->SetStatusFramePeriod(StatusFrameEnhanced::Status_2_Feedback0, 255, 10);
  MotorLR->SetStatusFramePeriod(StatusFrameEnhanced::Status_1_General, 255, 10);
  MotorLR->SetNeutralMode(NeutralMode::Brake);
  MotorLR->Follow(*MotorLF);
  MotorLR->SetSafetyEnabled(false);

  //Falcon500, 7.71:1 ratio, 4" wheels
  MotorRF = new WPI_TalonFX(constants::drive::kMotorRF_ID); //CAN
  MotorRF->ConfigFactoryDefault(kTimeoutMs);
  MotorRF->ConfigSelectedFeedbackSensor(FeedbackDevice::IntegratedSensor, 0, kTimeoutMs);
  MotorRF->SetInverted(true);
  MotorRF->ConfigNeutralDeadband(0.04, kTimeoutMs);
  MotorRF->SetNeutralMode(NeutralMode::Brake);
  MotorRF->ConfigNominalOutputForward(0, kTimeoutMs);
  MotorRF->ConfigNominalOutputReverse(0, kTimeoutMs);
  MotorRF->Config_kF(0, constants::drive::kF, kTimeoutMs);
  MotorRF->Config_kP(0, constants::drive::kP, kTimeoutMs);
  MotorRF->Config_kI(0, constants::drive::kI, kTimeoutMs);
  MotorRF->Config_kD(0, constants::drive::kD, kTimeoutMs);
  MotorRF->ConfigOpenloopRamp(constants::drive::kOpenLoopRamp,kTimeoutMs); 
  MotorRF->Config_IntegralZone(0, 400, kTimeoutMs);
  MotorRF->ConfigClosedLoopPeakOutput(0,1.0,kTimeoutMs);
  MotorRF->ConfigPeakOutputForward(1, kTimeoutMs);
  MotorRF->ConfigPeakOutputReverse(-1, kTimeoutMs);
  MotorRF->ConfigSupplyCurrentLimit(driveSCLC);//CURRENT_LIMITING
  MotorRF->ConfigStatorCurrentLimit(statorSCLC);//CURRENT_LIMITING
  MotorRF->SetStatusFramePeriod(StatusFrameEnhanced::Status_13_Base_PIDF0, 10, 10);
  MotorRF->SetStatusFramePeriod(StatusFrameEnhanced::Status_10_MotionMagic, 10, 10);
  MotorRF->ConfigVoltageCompSaturation(12.5);
  MotorRF->EnableVoltageCompensation(true);
  MotorRF->SetSafetyEnabled(false);
  
  //Falcon500, 7.71:1 ratio, 4" wheels
  MotorRR = new WPI_TalonFX(constants::drive::kMotorRR_ID); //CAN
  MotorRR->ConfigFactoryDefault(kTimeoutMs);
  MotorRR->SetInverted(true);
  MotorRR->ConfigSupplyCurrentLimit(driveSCLC);//CURRENT_LIMITING
  MotorRR->ConfigStatorCurrentLimit(statorSCLC);//CURRENT_LIMITING
  MotorRR->SetStatusFramePeriod(StatusFrameEnhanced::Status_2_Feedback0, 255, 10);
  MotorRR->SetStatusFramePeriod(StatusFrameEnhanced::Status_1_General, 255, 10);
  MotorRR->SetNeutralMode(NeutralMode::Brake);
  MotorRR->Follow(*MotorRF);
  MotorRR->SetSafetyEnabled(false);

  //BOSS dashboard on Drive Station computer
  ntBOSS = nt::NetworkTableInstance::GetDefault().GetTable("dashBOSS");

  AutoRev5_LeftBufStrm = new BufferedTrajectoryPointStream();
  AutoRev5_RightBufStrm = new BufferedTrajectoryPointStream();
  AutoFwd5_LeftBufStrm = new BufferedTrajectoryPointStream();
  AutoFwd5_RightBufStrm = new BufferedTrajectoryPointStream();
  AutoFwdCL_LeftBufStrm = new BufferedTrajectoryPointStream();
  AutoFwdCL_RightBufStrm = new BufferedTrajectoryPointStream();
  AutoFwdCR_LeftBufStrm = new BufferedTrajectoryPointStream();
  AutoFwdCR_RightBufStrm = new BufferedTrajectoryPointStream();

  InitBuffer(AutoRev5_LeftBufStrm,auto5_L,auto5_size,true);
  InitBuffer(AutoRev5_RightBufStrm,auto5_R,auto5_size,true);
  InitBuffer(AutoFwd5_LeftBufStrm,auto5_L,auto5_size,false);
  InitBuffer(AutoFwd5_RightBufStrm,auto5_R,auto5_size,false);
  InitBuffer(AutoFwdCL_LeftBufStrm,autoCurlLeft_L,autoCurlLeft_size,false);
  InitBuffer(AutoFwdCL_RightBufStrm,autoCurlLeft_R,autoCurlLeft_size,false);
  InitBuffer(AutoFwdCR_LeftBufStrm,autoCurlRight_L,autoCurlRight_size,false);
  InitBuffer(AutoFwdCR_RightBufStrm,autoCurlRight_R,autoCurlRight_size,false);
}

void DriveClass::DriveTank(double leftSpeed, double rightSpeed, double deadband, bool squareInputs, bool reversed)
{
  //static frc::SlewRateLimiter<units::dimensionless::scalar> slewLeft{JoystickSlewRate / 1_s};
  //static frc::SlewRateLimiter<units::dimensionless::scalar> slewRight{JoystickSlewRate / 1_s};  
  OutputToDrive outDrive;

  //leftSpeed = slewLeft.Calculate(leftSpeed);
  leftSpeed = clamp2(leftSpeed, -1.0, 1.0);
  leftSpeed = Deadband(leftSpeed, deadband);

  //rightSpeed = slewRight.Calculate(rightSpeed);
  rightSpeed = clamp2(rightSpeed, -1.0, 1.0);
  rightSpeed = Deadband(rightSpeed, deadband);

  if(reversed)
  {  //reverse the direction and swap right to left
    double tmp = leftSpeed;
    leftSpeed = -rightSpeed;
    rightSpeed = -tmp;
  }

  if (squareInputs) 
  {
    leftSpeed = std::copysign(leftSpeed * leftSpeed, leftSpeed);
    rightSpeed = std::copysign(rightSpeed * rightSpeed, rightSpeed);
  }
  outDrive.Left = leftSpeed;
  outDrive.Right = rightSpeed;
  MotorLF->Set(ControlMode::PercentOutput,clamp2(outDrive.Left,-1.0,1.0));
  MotorRF->Set(ControlMode::PercentOutput,clamp2(outDrive.Right,-1.0,1.0));

  
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    if(constants::kDriveLoggingEnabled) 
    {
      ntBOSS->PutNumber("Joy1_VAL", leftSpeed);
      ntBOSS->PutNumber("Joy2_VAL", rightSpeed);
      ntBOSS->PutNumber("MotorLF_SPD", GetLFSpeed());
      ntBOSS->PutNumber("MotorRF_SPD", GetRFSpeed());
    }
  }
}

void DriveClass::DriveArcade(double xSpeed, double zRotation, double deadband, bool squareInputs, bool reversed) 
{
  //static frc::SlewRateLimiter<units::dimensionless::scalar> slewX{JoystickSlewRate/ 1_s};
  //static frc::SlewRateLimiter<units::dimensionless::scalar> slewRot{JoystickSlewRate / 1_s}; 
  OutputToDrive outDrive;

  
  //xSpeed = slewX.Calculate(xSpeed);
  xSpeed = clamp2(xSpeed, -1.0, 1.0);
  xSpeed = Deadband(xSpeed, deadband);
  if(reversed) xSpeed = -xSpeed;

  //zRotation = slewRot.Calculate(zRotation);
  zRotation = clamp2(zRotation, -1.0, 1.0);
  zRotation = Deadband(zRotation, deadband);
  
  // Square the inputs (while preserving the sign) to increase fine control
  // while permitting full power.
  if (squareInputs) 
  {
    xSpeed = std::copysign(xSpeed * xSpeed, xSpeed);
    zRotation = std::copysign(zRotation * zRotation, zRotation);
  }

  double maxInput = std::copysign(std::max(std::abs(xSpeed), std::abs(zRotation)), xSpeed);

  if (xSpeed >= 0.0) {
    // First quadrant, else second quadrant
    if (zRotation >= 0.0) {
      outDrive.Left = maxInput;
      outDrive.Right = xSpeed - zRotation;
    } else {
      outDrive.Left = xSpeed + zRotation;
      outDrive.Right = maxInput;
    }
  } else {
    // Third quadrant, else fourth quadrant
    if (zRotation >= 0.0) {
      outDrive.Left = xSpeed + zRotation;
      outDrive.Right = maxInput;
    } else {
      outDrive.Left = maxInput;
      outDrive.Right = xSpeed - zRotation;
    }
  }
  MotorLF->Set(ControlMode::PercentOutput,clamp2(outDrive.Left,-1.0,1.0));
  MotorRF->Set(ControlMode::PercentOutput,clamp2(outDrive.Right,-1.0,1.0));

  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    if(constants::kDriveLoggingEnabled) 
    {
      ntBOSS->PutNumber("Joy1_VAL", xSpeed);
      ntBOSS->PutNumber("Joy2_VAL", zRotation);
      ntBOSS->PutNumber("MotorLF_SPD", GetLFSpeed());
      ntBOSS->PutNumber("MotorRF_SPD", GetRFSpeed());
    }
  }
}

void DriveClass::DriveArcade2(double xSpeed, double zRotation, double deadband, bool squareInputs, bool reversed) 
{
  OutputToDrive outDrive;
  double i1 = xSpeed;
  double i2 = zRotation;

  xSpeed = clamp2(xSpeed, -1.0, 1.0);
  xSpeed = Deadband(xSpeed, deadband);
  if(reversed) xSpeed = -xSpeed;

  zRotation = clamp2(zRotation, -1.0, 1.0);
  zRotation = Deadband(zRotation, deadband);
  
  // Square the inputs (while preserving the sign) to increase fine control
  // while permitting full power.
  if (squareInputs) 
  {
    xSpeed = std::copysign(xSpeed * xSpeed, xSpeed);
    zRotation = std::copysign(zRotation * zRotation, zRotation);
  }

  double maxInput = std::copysign(std::max(std::abs(xSpeed), std::abs(zRotation)), xSpeed);

  // Sign is used because `xSpeed >= 0.0` succeeds for -0.0
  if (!std::signbit(xSpeed)) {
    // First quadrant, else second quadrant
    if (!std::signbit(zRotation)) {
      outDrive.Left = maxInput;
      outDrive.Right = xSpeed - zRotation;
    } else {
      outDrive.Left = xSpeed + zRotation;
      outDrive.Right = maxInput;
    }
  } else {
    // Third quadrant, else fourth quadrant
    if (!std::signbit(zRotation)) {
      outDrive.Left = xSpeed + zRotation;
      outDrive.Right = maxInput;
    } else {
      outDrive.Left = maxInput;
      outDrive.Right = xSpeed - zRotation;
    }
  }
  double maxMagnitude = std::max(std::abs(outDrive.Left), std::abs(outDrive.Right));
  if (maxMagnitude > 1.0) {
    outDrive.Left /= maxMagnitude;
    outDrive.Right /= maxMagnitude;
  }
  MotorLF->Set(ControlMode::PercentOutput,clamp2(outDrive.Left,-1.0,1.0));
  MotorRF->Set(ControlMode::PercentOutput,clamp2(outDrive.Right,-1.0,1.0));

  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    if(constants::kDriveLoggingEnabled) 
    {
      ntBOSS->PutNumber("Joy1_VAL", i1);
      ntBOSS->PutNumber("Joy2_VAL", i2);
      ntBOSS->PutNumber("MotorLF_SPD", outDrive.Left);
      ntBOSS->PutNumber("MotorRF_SPD", outDrive.Right);
    }
  }
}

void DriveClass::TestDrive(double left, double right)
{
  left = clamp2(left, -1.0, 1.0);
  left = Deadband(left, 0.15);

  right = clamp2(right, -1.0, 1.0);
  right = Deadband(right, 0.15);

  MotorLF->Set(ControlMode::PercentOutput,left);
  MotorRF->Set(ControlMode::PercentOutput,right);
  
  static int counter = 0;
  counter++;
  if(counter >= 13)
  {
    counter = 0;
    ntBOSS->PutNumber("Joy1_VAL", left);
    ntBOSS->PutNumber("Joy2_VAL", right);
    ntBOSS->PutNumber("MotorLF_SPD", GetLFSpeed());
    ntBOSS->PutNumber("MotorRF_SPD", GetRFSpeed());
    ntBOSS->PutNumber("MotorLF_POS", GetLFDistance());
    ntBOSS->PutNumber("MotorRF_POS", GetRFDistance());
  }
}

double DriveClass::GetLFDistance()
{
  return MotorLF->GetSelectedSensorPosition() * constants::drive::kUnitsToFeet;
}

double DriveClass::GetRFDistance()
{
  return MotorRF->GetSelectedSensorPosition() * constants::drive::kUnitsToFeet;
}

double DriveClass::GetLFSpeed()
{
  return MotorLF->GetSelectedSensorVelocity(0) * constants::drive::kUnitsToFPS;
}

double DriveClass::GetRFSpeed()
{
  return MotorRF->GetSelectedSensorVelocity(0) * constants::drive::kUnitsToFPS;
}

void DriveClass::ZeroDistance()
{
  //set ticks equal to zero
  MotorLF->GetSensorCollection().SetIntegratedSensorPosition(0,kTimeoutMs);
  MotorRF->GetSensorCollection().SetIntegratedSensorPosition(0,kTimeoutMs);
}

void DriveClass::AutoSelect(int AutoSelected)
{
  AutoSelection = AutoSelected;
}

void DriveClass::AutoStart_Rev5()
{
  MotorLF->StartMotionProfile(*AutoRev5_LeftBufStrm, 10, ControlMode::MotionProfile);
  MotorRF->StartMotionProfile(*AutoRev5_RightBufStrm, 10, ControlMode::MotionProfile);
  if(constants::kDriveLoggingEnabled) ntBOSS->PutString("AutoStatus", "AUTO START REV");
}

void DriveClass::AutoStart_Fwd5()
{
  MotorLF->StartMotionProfile(*AutoFwd5_LeftBufStrm, 10, ControlMode::MotionProfile);
  MotorRF->StartMotionProfile(*AutoFwd5_RightBufStrm, 10, ControlMode::MotionProfile);
  if(constants::kDriveLoggingEnabled) ntBOSS->PutString("AutoStatus", "AUTO START FWD");
}

void DriveClass::AutoStart_CurveLeft()
{
  MotorLF->StartMotionProfile(*AutoFwdCL_LeftBufStrm, 10, ControlMode::MotionProfile);
  MotorRF->StartMotionProfile(*AutoFwdCL_RightBufStrm, 10, ControlMode::MotionProfile);
  if(constants::kDriveLoggingEnabled) ntBOSS->PutString("AutoStatus", "AUTO START CURVE LEFT");
}

void DriveClass::AutoStart_CurveRight()
{
  MotorLF->StartMotionProfile(*AutoFwdCR_LeftBufStrm, 10, ControlMode::MotionProfile);
  MotorRF->StartMotionProfile(*AutoFwdCR_RightBufStrm, 10, ControlMode::MotionProfile);
  if(constants::kDriveLoggingEnabled) ntBOSS->PutString("AutoStatus", "AUTO START CURVE RIGHT");
}

void DriveClass::AutoPeriodic()
{
  if(constants::kDriveLoggingEnabled) 
  {
    static int counter = 0;
    counter++;
    if(counter >= 13)
    {
      counter = 0;
      ntBOSS->PutNumber("MotorLF_POS", GetLFDistance());
      ntBOSS->PutNumber("MotorRF_POS", GetRFDistance());
      ntBOSS->PutNumber("MotorLF_SPD", MotorLF->GetSelectedSensorVelocity());
      ntBOSS->PutNumber("MotorRF_SPD", MotorRF->GetSelectedSensorVelocity());
    }
  }
}

bool DriveClass::AutoIsRunning()
{
  if (!MotorLF->IsMotionProfileFinished() && !MotorRF->IsMotionProfileFinished())
    return true;
  else return false;
}

void DriveClass::AutoReset()
{
	ZeroDistance();
  if(constants::kDriveLoggingEnabled) ntBOSS->PutString("AutoStatus", "RESET");
}

void DriveClass::Disable()
{
  MotorLF->Set(ControlMode::PercentOutput,0.0);
  MotorRF->Set(ControlMode::PercentOutput,0.0);
}

void DriveClass::CheckFaults()
{
  if(constants::kDriveLoggingEnabled)
  {
    FX_CheckFaults(MotorLF,"DRIVE LF",0);
    FX_CheckFaults(MotorLR,"DRIVE LR",1);
    FX_CheckFaults(MotorRF,"DRIVE RF",2);
    FX_CheckFaults(MotorRR,"DRIVE RR",3);
    ntBOSS->PutNumber("DriveFault", DriveFault);
  }
}

void DriveClass::ClearStickyFaults()
{
  MotorLF->ClearStickyFaults();
  MotorLR->ClearStickyFaults();
  MotorRF->ClearStickyFaults();
  MotorRR->ClearStickyFaults();
}

void DriveClass::FX_CheckFaults(WPI_TalonFX *Motor,std::string name,short bit)
{
  Faults f;
  StickyFaults sf;
  
  DriveFault = clearBit(DriveFault,bit);
  Motor->GetFaults(f);
  Motor->GetStickyFaults(sf);
  if(f.ResetDuringEn || f.SensorOutOfPhase || f.UnderVoltage)
  {
    DriveFault = setBit(DriveFault,bit);
    if(f.ResetDuringEn) printf("%s: %s\n",name.c_str(),"RESET DURING ENABLE");
    if(f.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"OUT OF PHASE");
    if(f.UnderVoltage) printf("%s: %s\n",name.c_str(),"UNDER VOLTAGE");
  }
  if(sf.ResetDuringEn || sf.SensorOutOfPhase || sf.UnderVoltage)
  {
    DriveFault = setBit(DriveFault,bit);  
    if(sf.ResetDuringEn) printf("%s: %s\n",name.c_str(),"STICKY RESET DURING ENABLE");
    if(sf.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"STICKY OUT OF PHASE");
    if(sf.UnderVoltage) printf("%s: %s\n",name.c_str(),"STICKY UNDER VOLTAGE");
  }
}

void DriveClass::SRX_CheckFaults(WPI_TalonSRX *Motor,std::string name,short bit)
{
  Faults f;
  StickyFaults sf;
  
  DriveFault = clearBit(DriveFault,bit);
  Motor->GetFaults(f);
  Motor->GetStickyFaults(sf);
  if(f.ResetDuringEn || f.SensorOutOfPhase || f.UnderVoltage)
  {
    DriveFault = setBit(DriveFault,bit);
    if(f.ResetDuringEn) printf("%s: %s\n",name.c_str(),"RESET DURING ENABLE");
    if(f.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"OUT OF PHASE");
    if(f.UnderVoltage) printf("%s: %s\n",name.c_str(),"UNDER VOLTAGE");
  }
  if(sf.ResetDuringEn || sf.SensorOutOfPhase || sf.UnderVoltage)
  {
    DriveFault = setBit(DriveFault,bit);  
    if(sf.ResetDuringEn) printf("%s: %s\n",name.c_str(),"STICKY RESET DURING ENABLE");
    if(sf.SensorOutOfPhase) printf("%s: %s\n",name.c_str(),"STICKY OUT OF PHASE");
    if(sf.UnderVoltage) printf("%s: %s\n",name.c_str(),"STICKY UNDER VOLTAGE");
  }
}

void DriveClass::InitBuffer(BufferedTrajectoryPointStream *bufstrm, const double profile[][2], int totalCnt, bool reverse)
{
    bool forward = !reverse; 
    TrajectoryPoint point; 

    bufstrm->Clear(); // clear the buffer, in case it was used elsewhere 
    for (int i = 0; i < totalCnt; ++i) // Insert every point into buffer
    {
        double direction = forward ? +1 : -1;
        double positionFeet = profile[i][0];
        double velocityFeetPerSec = profile[i][1];
        int durationMilliseconds = 10; 
        
        // for each point, fill our structure and pass it to API 
        point.timeDur = durationMilliseconds;
        point.position = direction * positionFeet * constants::drive::kFeetToUnits; //Convert Feet to Units
        point.velocity = direction * velocityFeetPerSec * constants::drive::kFPSToUnits; //Convert Feet/sec to Units/100ms
        point.auxiliaryPos = 0;
        point.auxiliaryVel = 0;
        point.profileSlotSelect0 = 0; 
        point.profileSlotSelect1 = 0; 
        point.zeroPos = (i == 0); // set this to true on the first point 
        point.isLastPoint = ((i + 1) == totalCnt); // set this to true on the last point 
        point.arbFeedFwd = 0; // you can add a constant offset to add to PID[0] output here 
        bufstrm->Write(point);
    }
}

void DriveClass::GetMaxAmps(bool SendToDash)
{
  double tmp;

  if(constants::kDriveLoggingEnabled)
  {
    tmp = MotorLF->GetOutputCurrent();  
    if(tmp > MotorLFMaxAmps) MotorLFMaxAmps = tmp;
    tmp = MotorLR->GetOutputCurrent();  
    if(tmp > MotorLRMaxAmps) MotorLRMaxAmps = tmp;
    tmp = MotorRF->GetOutputCurrent();  
    if(tmp > MotorRFMaxAmps) MotorRFMaxAmps = tmp;
    tmp = MotorRR->GetOutputCurrent();  
    if(tmp > MotorRRMaxAmps) MotorRRMaxAmps = tmp;
    if(SendToDash)
    {
      ntBOSS->PutNumber("DriveLF_AMP",MotorLFMaxAmps);
      ntBOSS->PutNumber("DriveLR_AMP",MotorLRMaxAmps);
      ntBOSS->PutNumber("DriveRF_AMP",MotorRFMaxAmps);
      ntBOSS->PutNumber("DriveRR_AMP",MotorRRMaxAmps);
    }
  }
}

void DriveClass::ResetMaxAmps()
{
  MotorLFMaxAmps = 0;
  MotorLRMaxAmps = 0;
  MotorRFMaxAmps = 0;
  MotorRRMaxAmps = 0;
}